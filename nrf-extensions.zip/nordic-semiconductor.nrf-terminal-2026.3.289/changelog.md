# nRF Terminal

The release notes for the extension are available in the [official documentation](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/rel_notes_overview.html).

# Version 2026.3.237

Welcome to the March 2026 release of the nRF Terminal extension.

Read below for the summary of the most important changes.

## Version 2026.3.289

### Bug fixes

- Fixed an issue with executing the RTT client when starting an RTT terminal. 

---

## Other improvements

- Connect RTT terminal with remote device. 


---

# Version 2026.1.235

Welcome to the January 2026 release of the nRF Terminal extension.

In this release, only general code maintenance changes and stability updates were implemented.


---

# Version 2025.8.103

Welcome to the August 2025 release of the nRF Terminal extension.

In this release, only an update to general dependencies was implemented. 




---

# Version 2024.9.14

Welcome to the September 2024 release of the nRF Terminal extension.

In this release, only minor improvements and bug fixes were implemented.


---

# Version 2024.2.78

Welcome to the February 2024 release of the nRF Terminal extension.

Read below for the summary of the most important changes.

## Changes in 2024.3.15

*   Restored the command for saving terminal content to a file. 

----

*   Improved connection management on busy or disconnected serial ports. 
*   Fixed missing terminal profile icons. 



---

# Version 2023.9.29

Welcome to the September 2023 release of the nRF Terminal extension.

This release, we have been working on improving the following areas:

-   [Serial port configuration](#serial-port-configuration)

## Serial port configuration

Entering data bits and stop bits when setting up a serial connection was previously done through free text inputs. Now these are values are configured using a quickpick.



---

# Version 2023.6.78

Welcome to the June 2023 release of the nRF Terminal extension.

This release, we have been working on improving the following areas:

- [Improved setup](#improved-setup)
- [Add carriage return to RTT output](#add-carriage-return-to-rtt-output)

## Fixes in 2023.7.47

- Fixed an issue with initiating the RTT connection to nRF5340 from the [**Connected Devices**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_connected_devices.html) View.

## Improved setup

The process for setting up new serial terminals was a bit more complicated than it needed to be. After gathering opinions from the extension users, we streamlined this process by introducing changes described below.
For the overview of the whole process, read [How to connect to a device](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/bd_work_with_boards.html#how-to-connect-to-a-device).

### Allow picking a connected device

Because the serial port names are not easily associated with the connected devices, the nRF Terminal extension now lets you pick serial ports from the [list of connected devices](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_connected_devices.html) first, instead of only showing the assigned COM port number. The same mechanism is also used for the RTT setup.

### Use device name as terminal name <span title="This change was suggested by a user!">💬</span>

If your device is available in the nRF Connect for VS Code extension's list of connected devices and you assigned it a [custom device name](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_connected_devices.html#contextual-actions), this name will now be used as the terminal name when you create an RTT or serial terminal.

### Inline connection parameter configuration

You can now configure the default parameters for each port or device directly in the serial port device picker (or choose from previously used parameter values). You do not have to confirm the connection parameters for each device in a separate step anymore.

![Change port settings](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/ui_connected_devices_change_port_settings.avif "Change port settings")

---

## Add carriage return to RTT output

The RTT terminal now adds carriage return (`\r`) to newlines in its terminal output. Before, it ran with a normal newline (`\n`), which would render the terminal unusable. The reason for such behavior was an implementation detail in the VS Code terminal, which caused each line to be offset by the length of the previous line, instead of restarting its horizontal position.


---

# Version 2023.4.15

Welcome to the April 2023 release of the nRF Terminal extension.

This release, we have been working on improving the following areas:

- [nRF Terminal profile: Switched to native terminal](#nrf-terminal-profile-switched-to-native-terminal)
- [Housekeeping](#housekeeping)

## nRF Terminal profile: Switched to native terminal

Up until now, the nRF Terminal has been using our own terminal implementation. This solution worked reasonably well, but has always led to some strange behavior. Recent changes to the Visual Studio Code API have made it possible to hook the nRF Terminal into the native Visual Studio Code terminal window, so in this release we have replaced our own implementation with the Visual Studio Code's own.

![Native nRF Terminal](https://user-images.githubusercontent.com/7857838/210248582-d9ad3806-a87d-42cb-b538-a524be9dbe2d.gif)

This brings a number of benefits:

* Considerably increased performance and stability
* Possibility to move Terminal around anywhere within the Visual Studio Code screen
* Multiple terminals that can run at once
* Full support for ANSI escape codes
* Adoption of global terminal settings, such as font family and scrollback

You can access the new terminal in the same way as before, using either the [Connected Devices View actions](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_connected_devices.html#view-actions) or the [nRF Terminal commands](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/settings.html#nrf-terminal-commands) in the **Command Palette**. Alternatively, you can now also start the new terminal using the [nRF Connect and nRF Terminal launch profiles](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_panel.html#nrf-connect-and-nrf-terminal-profiles).

> ✏️ **Note**
>
> Since the standalone nRF Terminal window was removed, the **Start Terminal With Previous Configuration** command is no longer available as an icon in the UI. You now need to run it through the **Command Palette**.

As a result of this change, the **nRF Terminal** window in the **Panel View** is now deprecated and contains only a notification of the switch to the native Visual Studio Code terminal. The **nRF Terminal** window will be removed in one of the future releases.

![nRF Terminal window with the notification of the switch](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/terminal/screenshots/PR1942.avif)

---

## Housekeeping

* The minimum required version of VS Code has been increased to v1.66.



---

# Version 2022.11.29

Welcome to the November 2022 release of the nRF Terminal extension.

In this release, we fixed a minor issue that happened whenever the nRF Terminal panel would be closed (hidden) and reopened, where the **nRF Terminal Panel View** would not scroll to the latest line at the bottom of the log and instead would show the line at the top of the log. Now the panel correctly scrolls down to the latest line in the log.


---

# Version 2022.9.15

Welcome to the September 2022 release of the nRF Terminal extension for Visual Studio Code.

* **Original release version:** v2022.9.15

We made some minor tweaks to the nRF Terminal **Panel View** in this release.

The **Save** button in the **nRF Terminal Panel View** **Toolbar** has been renamed to **Save Terminal Output to File** to be more descriptive.
The **Save Terminal Output to File** button will now only be shown after you have connected your device to the terminal at least once. Previously, this button would not be helpful if you had not connected to the terminal before and it would appear as soon as you opened the **nRF Terminal Panel View**.

Additionally, we made it so that the saved output file will now save in your home directory and have a more useful filename that includes the date and time. For example, the output file could be saved with the following name: `terminal_output_2022-09-05T10-54-40.573Z.txt`.

## 2022.10.7 additionally fixes the following issues:

* **Saving log file on Windows:** When pressing the **Save Terminal Output to File** button on Windows, the extension would mangle the file path, causing an error instead of saving the file.


---

# Version 2022.7.21

Welcome to the July 2022 release of **nRF Terminal** extension for VS Code.

Read the following sections for an overview of the changes we've made.

## Save the content of the terminal to file

You can now save the content of the **nRF Terminal** into a file using a button. Look for the new button icon in the title bar of the **nRF Connect Terminal Panel View**.

![Save terminal content](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/terminal/screenshots/PR151.avif "Save terminal content")

## Improved finding of J-Link on Windows

Based on your feedback, we have improved the extension's ability to find J-Link.
On Windows, the extension will now use the Windows registry to determine the path of the latest J-Link installation. As a fallback, it'll check the default paths for both 32-bit and 64-bit installations.

## Fixed a bug with repeated RTT connections

We have fixed a bug where repeated RTT connections without manual disconnection would result in an inactive,
disconnected terminal state.




---

# Version 2022.4.61

Welcome to the April 2022 release of nRF Terminal for VS Code.

## Copy and paste

The typical copy and paste keyboard shortcuts (Ctrl-C and Ctrl-V) do not work in the nRF Terminal. To avoid confusion, we removed the context menu in the terminal webview because they suggested these shortcuts.

We have now included a section called [**Keyboard Shortcuts**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/keybindings.html) in the main nRF Terminal documentation page, showing you which shortcuts can be used in the terminal.

## Status bar item improvements

We have made a few improvements to the nRF Terminal status bar item.

The status bar item is now hidden when no terminal session is active. To start a new terminal session, you need to visit the **nRF Terminal** panel, or the nRF Connect extension's **Connected Devices** panel.

The status bar item now changes to a warning color whenever a device is reconnecting, making it easier to notice.

![nRF Terminal status bar item warning color](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/terminal/screenshots/PR135.png "nRF Terminal status bar item warning color")

## Terminal title bar buttons

The terminal title bar now includes buttons to let you connect and disconnect with just a click. We also added a reconnect button, making it easy to start the terminal with the last-used configuration.

![Terminal connect buttons](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/terminal/screenshots/PR136.avif "Terminal connect buttons")

## Setup

When starting a new terminal session from locations other than the **Connected Devices** panel, the extension presents a drop-down menu of serial ports.
On Linux, this previously included all virtual consoles under `/dev/`, most of which are irrelevant in this setting so we have removed these.
To make setup a little easier, the extension now only presents `/dev/ttyACM` ports in the drop-down, and provides an additional option to let you enter a custom port name.

## Welcome prompt

We added a tooltip that shows you details of the last configuration used, if applicable, by hovering your cursor over the "last used configuration" text from in the **Welcome** prompt.
If there was no previous configuration, then this help line will not be displayed, and the reconnect button will not appear.

![Connect with previous configuration](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/terminal/screenshots/PR138.avif "Connect with previous configuration")


---

# Version 2022.3.16

## Added

* `Clear Terminal` command with an icon on the status bar.
* History of the serial port connection settings to pick from when making a new connection.

## Fixed

* Content security policy warning about webview.

## Updated

* Terminal view icon.
* Show connection parameters in the **Terminal** panel.
* Keep the terminal content when disconnecting.


---

# Version 2022.1.30

## Fixed

* Welcome message sometimes not showing on load.
* Setting custom memory address for RTT block.


---

# Version 2021.11.7

## Fixed

* The connection flow now exits when quick pick is dismissed.


---

# Version 2021.9.26

## Updated

* End-of-line handling for RTT sessions has been improved.


---

# Version 2021.9.20

## Added

* Terminal is revealed and focused when starting connection.


---

# Version 2021.8.13

Initial release.
