# nRF Terminal

Nordic Semiconductor’s nRF Terminal extends the [nRF Connect for VS Code](https://marketplace.visualstudio.com/items?itemName=nordic-semiconductor.nrf-connect) extension with terminal profiles to connect to your devices over serial ports or RTT.

**Note:** For a complete user experience, install the full [nRF Connect Extension Pack](https://marketplace.visualstudio.com/items?itemName=nordic-semiconductor.nrf-connect-extension-pack).

For detailed information about the extension features, see the extension's [Panel View](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_panel.html) documentation site.

## Use custom terminal profiles

nRF Terminal adds serial connection options to VS Code in the **Terminal Panel View**. In the **Panel Toolbar**, you can expand the connection profile drop-down menu to access two custom terminal profiles that provide access points to your device: **nRF RTT Terminal** and **nRF Serial Terminal**.

![RTT and serial terminal options](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/nrf-terminal-dropdown-menu-options.avif "RTT and serial terminal options")

## Feedback

Let us know what you think using the [**Give Feedback**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_welcome.html#toolbar-actions) form within the extension, or ask questions in the [Nordic DevZone](https://devzone.nordicsemi.com/).