# nRF DeviceTree

Nordic Semiconductor’s nRF DeviceTree extends the [nRF Connect for VS Code](https://marketplace.visualstudio.com/items?itemName=nordic-semiconductor.nrf-connect) extension to offer devicetree language support.
The devicetree language allows you to configure several different devices such as LEDs, a display, and sensors, to have better control of your project.

**Note:** This extension can only be used together with the [nRF Connect for VS Code](https://marketplace.visualstudio.com/items?itemName=nordic-semiconductor.nrf-connect) extension. For a complete user experience, install the full [nRF Connect Extension Pack](https://marketplace.visualstudio.com/items?itemName=nordic-semiconductor.nrf-connect-extension-pack).

For detailed information about the extension, see the **[Devicetree View](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html)** documentation site.

## Devicetree language support

[Devicetree language support](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/how_to_create_dt_files.html) is one of the main features of nRF DeviceTree.

* Syntax validation and highlighting

* Code completion for the devicetree language, which validates properties nodes, and phandle cell names.

    ![Code completion](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/code-completion.avif "Code completion")

* Add missing required properties

    ![Add required properties](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/gif/add-required-properties.gif "Add required properties")

* Linting: including reference validity, bus matching, and GPIO collision detection

* C file macro argument and directive completion

## Devicetree Visual Editor

nRF DeviceTree extension features the Devicetree Visual Editor, which allows you to edit your devicetree configuration using an intuitive GUI.

![Devicetree Visual Editor](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/dve2_overview_general.avif "Devicetree Visual Editor")

Read more about the editor in [How to work with Devicetree Visual Editor](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html) and [Devicetree Visual Editor UI](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve.html).

## Information about devicetree context

From the **Devicetree View**, you can check your devicetree configuration from one location.

![Devicetree context](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/dve2_overview_contexts.avif "Devicetree context")

For more information, read the [Devicetree context](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html) page.

## Creating an overlay file

[Create devicetree overlay files](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/bd_overlay.html) for your application in just a few seconds, by clicking on the **Config files** folder found in your application's [**Details View**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_details.html).

![Create a devicetree overlay file](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/create_overlay_file.avif "Create a devicetree overlay file")

## Feedback

Let us know what you think using the [**Give Feedback**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_welcome.html#toolbar-actions) form within the extension, or ask questions in the [Nordic DevZone](https://devzone.nordicsemi.com/).
