# nRF DeviceTree

The release notes for the extension are available in the [official documentation](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/rel_notes_overview.html).

# Version 2026.3.617

Welcome to the March 2026 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

---

## Other improvements

- Added support for nRF54LM20B and nRF54LS05B. 


---

# Version 2026.1.448

Welcome to the January 2026 release of the nRF DeviceTree extension.

In this release, only general code maintenance changes and stability updates were implemented.


---

# Version 2025.8.140

Welcome to the August 2025 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

---

## [Problems View](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_panel.html#extension-related-issues-in-problems)

- Added the `unnecessary` diagnostic tag to disabled nodes. 
- Changed the diagnostic level for the address range collision from warning to information. 
- Changed the diagnostic level for the warning when the source file that originates the warning is not in [active context](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts) from warning to information. 
- Changed the diagnostic level for the warning when a binding is not found from warning to hint with the `unnecessary` diagnostic tag. 

---

## [Devicetree Visual Editor](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html)

- Fixed an issue where adding pin controls would not add both `default` and `sleep` states. <span title="This change was suggested by a user!">💬</span> 

---

## Bug fixes

- Fixed an issue where multiple text edits done in the Devicetree Visual Editor would not show in the file. <span title="This change was suggested by a user!">💬</span> 
- Fixed a regression issue where peripherals were missing on nRF52 SoCs. 
- Fixed an issue where the GPIO pin overlap information would not show all items linked to the overlap. 

---

# Version 2025.4.22
Welcome to the April 2025 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

## General changes

* Sorted items in the [**Build Contexts**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_build_contexts.html) to match the order of items in the [**Applications View**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html). 

---

## Bug fixes

* Fixed an issue with nRF54L15 showing an unsupported baud rate. 
* Added pin mappings for nRF54L15 and nRF54H20. 

---

# Version 2024.12.15

Welcome to the December 2024 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

## General changes

* Added support for board definitions that use `extend`. 
* Extended the API to pass more complete devicetree context information from the build configurations. 
* Removed some undocumented obsolete features. 

---

## Bug fixes

* Fixed an issue where the description of the [**Nodes View**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#nodes-view) description would not always update. 


---

# Version 2024.11.16

Welcome to the November 2024 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

### Changes in 2024.11.36

## Bug fixes

* Fixed an issue where the Devicetree Visual Editor would show an invalid [build context](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts) when selecting certain overlay files. 

---

## General changes

* Added support for using the `build_info.yml` file to read build information. 
* Added a build log entry about Kconfig language server not being able to start for builds. The notification asks the user to rebuild. When required, it is displayed in the **Problems** panel in the [Panel Views](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_panel.html). 

---

## Bug fixes

* Fixed an issue with parsing the size of external memory peripherals. <span title="This change was suggested by a user!">💬</span> 



---

# Version 2024.9.26

Welcome to the September 2024 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

## [Devictree language support](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/ncs_configure_app.html#devicetree-language-support)

- Added the variable substitution for devicetree settings. <span title="This change was suggested by a user!">💬</span> 
- Added autocomplete suggestion support for `delete-property` and `delete-node`. 
- Added complete support for devicetree bindings based on the build context. 
- Added all folders for board architectures from `zephyr/dts/`. 
- Improved lint messages and compatible lint warnings. 
- Improved the glob mechanism to account for incorrectly named devicetree binding files (`.yml`). 

---

## [Devicetree Visual Editor](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html)

- Added a mechanism for updating the active [build context](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts) between the nRF Connect, the nRF DeviceTree, and the nRF Kconfig extensions.  
- Fixed an issue with the editor window being blank when opening Visual Studio Code. 

### [Nodes View and Visual Editor](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html)

- Added a warning about using [Partition Manager](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/scripts/partition_manager/partition_manager.html) to define memory partitions. <span title="This change was suggested by a user!">💬</span> 
- The first empty pin is now automatically preselected when adding LEDs, buttons, or GPIOs. 

### [Context Overview](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html)

- Renamed this UI section to Context Overview, in line with the introduction of [build contexts](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts).
- Added build directory as the description of this UI section. 
- Removed the tree item with board info. 

### Bug fixes

-   Fixed an issue with handling `-pin` properties that are not `phandles`. <span title="This change was suggested by a user!">💬</span> 
-   Fixed an issue with the broken devicetree activation when the context was misconfigured. 
-   Fixed an issue with adding a new label to ancestors. 
-   Fixed an issue with rendering devices connected to regulators. 

---

## Known issues

We are aware of the following known issues that affect this release of the extension.

### Visual Studio Code does not detect all files used by a build

In some cases, especially for build configurations that use sysbuild or shields (or both), some devicetree files (`.overlay`,`.dts`,`.dtsi`) are not picked up by the active build context.
This issue has the following consequences:

* The devicetree language server will be unaware of the context of these files when computing results.
* The Devicetree Visual Editor will render an incomplete state for that context.
* Tooltips will not be shown for these files.


---

# Version 2024.2.418

Welcome to the February 2024 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

## Changes in 2024.3.78

The changes in this release are all related to the Devicetree Visual Editor:

* Editor behavior

    * Added input validation to property components in the **Peripherals** view. 
    * Changed the **Nodes** view behavior so that the view is now persistent and selecting a node in it makes the node active also in the **Peripherals** view. 
    * Changed the labelling logic for adding new memory partitions in **Peripherals** so that the partitions are labelled correctly. 
    * Removed the visibility restrictions of the editor treeviews. 

* UI changes

    * Added the add button for generic IOs. 
    * Made WAKE pins of SPI peripherals visible in the **Peripherals** view. 
    * Reworked interaction with channel settings of channel peripherals, such as ADC or PWM, by making the configure button only show on hover for channels connected to a node. 
    * Locked ADC pins in the **Pins** view given their hardcoded assignments. 
    * Moved the context menu items of the nodes in **Nodes** view to the **...** more actions menu. 
    * Disabled the standard copy-paste context menu items in **Node Inspector** and **Pin Overview**. <span title="This change was suggested by a user!">💬</span> 
    * Replaced the pin icon in the editor. 

* Bugfixes

    * Fixed devicetree node type duplication when changing Zephyr base. 
    * Fixed a crash triggered by the code behind Visual Studio Code issue [#204178](https://github.com/microsoft/vscode/issues/204178). 
    * Fixed several rendering and alignment issues in the **Pins** and **Peripherals** view. 
    * Fixed several issues related to node selection and property editing. 
    * Fixed the PWM property wrapping in the **Node Inspector**. 

---

## [Devicetree Visual Editor](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html)

* Implemented a complete overhaul of the Devicetree Visual Editor.<br/>
  The new editor replaces the old circuit views with a new **Peripherals** view, which gives an overview of the different components on your board, their pins, settings, and relationships.
* There are a lot of additional changes and enhancements that we hope will reduce the learning curve for new Devicetree users and improve the workflow for existing users:

    * The **Devicetree View** has been moved to its own Visual Studio Code sidebar.
    * Removed the address bar at the top with a node-specific header.
    * Diagnostics are now shown in the editor.
    * Added a new **Add Device** workflow, making it easier to add new devices and features to your board.
    * Pin assignments can now be dragged and dropped in the **Pins** view.

* Implemented several small enhancements to how the changes made in the editor are applied to text files.
* Fixed several bugs in property assignments and addition workflows.

---

## [Devicetree language support](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/ncs_configure_app.html#devicetree-language-support)

* Improved code completion context awareness.  
* Added support for child bindings, including other bindings directly. 
* Made linter ignore properties in deleted node entries. 
* Fixed handling of `/delete-property/`. 

---

## Linting

* Added reporting of address collisions in all nodes involved in the collision. 
* Stopped emitting compatible warnings for root and `/soc/` node. 
* Removed invalid warning on `reg-names` property. 
* Improved diagnostic on invalid phandle cells. 
* Fixed address collision lint warning that would show the wrong address. 
* Fixed flash partitions that would expect addresses in the global address space instead of the local one. 


---

# Version 2023.11.120

Welcome to the November 2023 release of the nRF DeviceTree extension.

Read below for the summary of the most important changes.

---

## Devicetree language support

* Fixed an issue with the code completion for `pinctrl` properties, which no longer complete to an empty string.

---

## Devicetree parser

* Fixed an issue with the parsing of line comments embedded in the block comments.
* Stopped emitting warnings on duplicated defines.

---

## C language support

* Added **Go to Definition** support for [Devicetree macros in C files](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/ncs_configure_app.html#c-file-macro-arguments-and-definitions).

---

## Linting

* Added `/reserved-memory/` as a standard node type.
* Stopped marking node entries as useless if the entry has a label.

---

## Context management

* Fixed an issue with the [**Devicetree View**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html) section not updating until a devicetree file is opened.


---

# Version 2023.9.57

Welcome to the September 2023 release of the nRF DeviceTree extension.

This release, we have been working on improving the following areas:

- [Export circuit visualizations to SVG](#export-node-visualizations-to-svg)
- [Low power mode toggle](#low-power-mode-toggle)
- [Bug fixes](#bug-fixes)

## Export node visualizations to SVG

In this release, we've added the ability to export the visualizations of individual nodes to SVG. This can be useful for sharing designs with colleagues, saving them for later reference, and importing them into other applications. Here is an example of an exported `gpio-leds` node:

![Exported gpio-leds node](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/dts_export.avif "Exported gpio-leds node")

To export a visualization, right click on it and select **Export Visualization**. Choose a folder to save the export, and click **Open** to open the SVG in your default SVG viewer. It's currently only possible to export a single visualization at a time. In the future, we're planning to add support for exporting multiple visualizations into one document, as well as additional formatting options.

## Low power mode toggle

A new **Low power mode** toggle was added to the Pin Management widget, allowing the [`lower-power-enable`](https://docs.nordicsemi.com/bundle/ncs-2.4.2/page/nrf/app_dev/pin_control/index.html#pin_control_in_nrf) flag to be enabled and disabled through the graphical interface.

![Lower power mode flag](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR2777.avif "Low power mode flag")

## Bug fixes

* Fixed a regression that prevented dropdowns from expanding past modal boundaries.
* Fixed the unintentionally short width of Boolean properties.
* Fixed an issue where the Pin Assign widget could become lost if the window dimensions were reduced too much.
* Fixed a bug that could result in invalid duplicate pin assignments being rendered. These are now filtered out, and only the last valid assignment is shown.
* Fixed laggy behavior that could occur when typing quickly into number and string properties.



---

# Version 2023.6.108

Welcome to the June 2023 release of the nRF DeviceTree extension.

This release, we have been working on improving the following areas:

- [General Visual Devicetree Editor changes](#general-visual-devicetree-editor-changes)
- [Pin Overview](#pin-overview)
- [Circuit schematics](#circuit-schematics)

## Fixes in 2023.7.56

- Fixed a regression issue that would make the breadcrumb bar show the wrong item.
- Fixed various visual issues in the Devicetree Visual Editor.

## General Visual Devicetree Editor changes

The Visual Devicetree Editor is still in the experimental stage of development.

### Show warning when editing board file in the SDK

When working with devicetree files, it is easy to accidentally make a change in a source file that belongs to the nRF Connect SDK when you really meant to make the change in a file that belongs to your application.

One common example of such a pitfall is when you forget to define an overlay file and start working directly on the board file of a development kit. If you maintain your own board files, this is still a valid usage scenario, but if you do not, you might end up breaking other applications.

To help avoid this, the extension now warns your if you are about to edit a board file under the `nrf` or `zephyr` directories in the SDK. Hovering over the warning shows a tooltip from which you can create a new overlay file. The button works the same way as the [corresponding option in the **Details View**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/how_to_create_dt_files.html).

![Warning tooltip when editing an SDK file](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR2533.avif "Warning tooltip when editing an SDK file")

### Filter compatible properties by context

When [adding child nodes](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html#how-to-add-new-nodes), the list is filtered according to a series of parent-specific rules, for example to avoid bus nodes being added outside buses. The same filtering logic has now been applied to the compatible [property input box](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html#how-to-add-new-properties) on existing nodes.

### Fixed integer enum properties being inserted as strings <span title="This change was suggested by a user!">💬</span>

Some properties have enum definitions in their binding. These definitions dictate a limited set of valid options. When these properties were meant to be interpreted as integers, the extension would mistakenly insert them as strings in the generated devicetree code, which would break the type checker in the compilation. This issue is now fixed.

### Widened header node picker <span title="This change was suggested by a user!">💬</span>

The header's node selection drop-down was unnecessarily narrow, and would occasionally render with a scrollbar that would hide the node description. This drop-down now uses all the horizontal space available and ensures that the scrollbar does not render on top of the node name.

### Add scrollbar to the Add Node modal

The [**Add Node**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_devicetree_editor.html#how-to-add-new-nodes) modal could potentially get too long for the screen if the selected node contained too many properties. The new scrollbar makes this modal usable for any node.

---

## Pin Overview

One of the most useful aspects of the [**Schematic Preview**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#peripherals) in the **Devicetree Visual Editor** is the **Pin Overview**, which received some improvements.

### New Pin Management node selector

We redesigned the **Existing Assignments** overview of the [**Pin Management** widget](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#pin-overview-panel) to feature a single-select box that shows the current assignment and lets you choose between them, making it easier to pick the right node, pin function, and state.

![Pin Management widget: Existing Assignments tab](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR2695.avif "Pin Management widget: Existing Assignments tab")

### Filtering GPIO ports by enabled status

To accommodate devices with highly flexible pin configuration schemes, the editor now hides ports that have been explicitly disabled with `status = "disabled"`.

### Supporting legacy "-pin" pin configuration

Both the PHandle and Pin control mechanisms for configuring GPIO pins have standard configuration flags. This was different with the (now deprecated) `-pin` pin assignments, which had an ad-hoc scheme for configuring mechanisms like pull-up resistors. To support users still working with the nRF Connect SDK v1.x, this legacy representation will now work properly in the pin configuration interface.

If a node has at least one such legacy `-pin` configured, this format is used for the node and the `pinctrl` format is filtered out. If `pinctrl` is available and there are no legacy `-pin` pins, the legacy pin definitions are filtered out.

The output and drive buttons are disabled for legacy pins, as they did not have a mechanism for this in Devicetree.

### Open relevant pin assignment

When a pin has multiple assignments, the first assignment is presented normally on the [**Pin Overview**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#pin-overview-panel), while the others are shown as cascading labels underneath. Previously, clicking any of the assignments would always open a popup for the first assignment. Now, clicking any of the secondary assignments will also open the popup for the relevant assignment.

---

## Circuit schematics

The [Circuit schematics](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#peripherals) represent the currently selected part of the Devicetree. They let you compare your changes with your hardware schematics, making it easier to find inconsistencies.

### Jumping to pin from the circuit schematic

Clicking on a pin reference in a circuit schematic will now jump to the [**Pin Overview**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#pin-overview-panel) and open the [**Pin Management** widget](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#pin-overview-panel) for the pin.

### Removed SoC circuit schematic

The SoC circuit schematic would show up when the SoC was selected in the sidebar, but did not provide much value compared with the [**Pin Overview**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_editor.html#pin-overview-panel). We have removed it in favor of the **Pin Overview**.

### Corrected LED connection to GND/VDD when active high/low <span title="This change was suggested by a user!">💬</span>

The LED and PWM LED circuit schematics displayed the LEDs polarity the wrong way around, showing LEDs configured as active high connected to VDD, while they should have been connected to ground, and vice-versa.


---

# Version 2023.4.61

Welcome to the April 2023 release of the nRF DeviceTree extension.

This release brings improvements to the following areas:

- [Devicetree Visual Editor](#devicetree-visual-editor)
- [Links in build output](#links-in-build-output)
- [Changes to linting rules](#changes-to-linting-rules)
- [Editing](#editing)
- [Devicetree View](#devicetree-view)
- [Workspace management](#workspace-management)
- [Housekeeping](#housekeeping)
- [Bug fixes](#bug-fixes)

## Devicetree Visual Editor

Regular feedback from users indicates that one of the hardest parts of writing applications for the nRF Connect SDK is dealing with devicetree. Many of the concepts required to understand devicetree are new to embedded developers, and the devicetree language itself does a poor job of exposing them and making them understandable.

To address this, the **Devicetree Visual Editor** was developed, an intuitive graphical interface that lets you interact with devicetree in a natural way and using an interface similar to the rest of the Visual Studio Code UI.

![Devicetree Visual Editor preview](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR1712.avif)

When you make changes using the **Devicetree Visual Editor**, the appropriate devicetree code will be written for you and added to your board's `.overlay` or `.dts` file. The editor acts on exactly the same devicetree file that you would edit yourself. You do not have to use it, but if you do, you can open it side-by-side with the overlay file and observe the changes as you make them. This is a great way to learn and get more familiar with the devicetree language.

The editor includes lots of features, including:

* A visual representation of the compiled devicetree structure
* Facilities for assigning nodes to pins and vice-versa
* An interactive schematic representing devicetree nodes
* Dedicated UI components for complicated devicetree concepts, such as nexus maps and registers

For this release, the **Devicetree Visual Editor** is marked as *experimental*. This means it is just the initial release of the editor, and development will continue in future releases. Your feedback is valuable and appreciated, so please feel free to provide it through the dedicated **Give feedback** link in the lower left hand corner of the editor!

For more information and comprehensive documentation, visit the dedicated [documentation page](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve.html).

---

## Links in build output

The build output now provides links to the corresponding node or property for devicetree C macros.

For example, on the following image, the C macro `DT_N_S_soc_S_rtc_40024000_P_reg` represents the `/soc/rtc@40024000/reg` property, and any occurrence of it is now clickable as a link in the build terminal and user terminals.

![Clickable links in build output](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR2262.avif)

---

## Changes to linting rules

The linting rules have received the following changes:

* The linting message for duplicate entries inside nexus maps is now formatted correctly.
* The `compatible` property is no longer reported as missing on the `alias` and `chosen` nodes.
* The erroneous lint condition that all child nodes need `compatible` properties has been removed.

---

## Editing

Several editing-related issues have been fixed and the autocompletion behavior for the devicetree language support has been modified.

### Stopped listing type bindings with no compatibles

Unless a binding file has a `compatible` entry, it cannot be used as a type directly. These files are just made for including from other bindings, and can be considered abstract base classes for other devices. To this end, they are no longer listed in places where autocompletion is provided for binding files.

### Stopped returning the current node entry in autocomplete

Every time you would run the **Go to Definition** on a label reference node, it would include the node you clicked on in the result, which would then open the CodeLens UI with the current selection as the main result. This is not needed when there is just one other definition, so now the extension will go directly to the other reference.

### Fixed invalid semicolon insertions

There were several cases where the automatic semicolon insertion for devicetree files did not work correctly:

* It did not check for existing semicolons, and would always insert another if a closing bracket was added.
* It inserted the semicolon at the end of the replaced range instead of the end of the inserted range. This would put semicolons in the middle of the insertion if the new text was longer than the old.

Both of these issues are now fixed.

---

## Devicetree View

The introduction of the **Devicetree Visual Editor** made it necessary to update the [Devicetree View](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html).

### Removed buttons for devicetree contexts

With the new **Devicetree Visual Editor**, the buttons that were available for some of the [Devicetree contexts](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html) have become somewhat redundant. The View now provides a read-only overview of these contexts.

### Switched to IEC designations for units

Both the Devicetree View and the Devicetree Visual Editor are now using the standard IEC designations when formatting units (for example, KiB instead of kB).

---

## Workspace management

Changes described in this section are related to the extension interaction with [west](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/west_about.html).

### Support glob patterns in devicetree.modules setting <span title="This change was suggested by a user!">💬</span>

Glob support was added to the ``devicetree.modules`` setting to ensure that all west modules in standard paths are included in the bindings indexing and `include` directory search.

The default value for this setting has also been changed, so that nRF54 and ZMK directories are discovered automatically.

---

## Housekeeping

* The minimum required version of Visual Studio Code has been increased to v1.66.

---

## Bug fixes

* Fixed an occasional warning on startup that complained about being unable to "read `indexOf` from undefined".


---

# Version 2022.11.153

Welcome to the November 2022 release of the nRF DeviceTree extension.

Read the following sections for an overview of the changes we've made.

## `*-gpios` pins now registered in the Sidebar
The GPIO list in the [DeviceTree View](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html) now includes pins that are assigned with properties ending in `-gpios`, such as SPI `cs-gpios`. Previously, only `pinctrl` pins, legacy `-pin` properties, and `gpios` properties were listed.

## Cell count fallback
We fixed a bug where the address and the size cells within devicetree nodes would normally fall back to `2` and `1`, respectively, if they're missing from the node. Now, they take the type's `const` into account.


---

# Version 2022.9.11

Welcome to the September 2022 release of the nRF DeviceTree extension for Visual Studio Code.

* **Original release version:** v2022.9.11

For this release, we added a feature to the [**Show Compiled Devicetree Output**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_dve_overview.html#compiled-output-preview) file that shows the source file of the definition in the selected line. To view this, select a line from the compiled devicetree output file and the source of that definition will be shown at the end of that line.

![View definition in source file](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR1492.gif "View definition in source file")


---

# Version 2022.7.36

Welcome to the July 2022 release of **nRF DeviceTree** extension for Visual Studio Code.

In this release, we have worked on the following areas:

- [Devicetree editing improvements](#devicetree-editing-improvements)
- [Devicetree View improvements](#devicetree-view-improvements)
- [Performance improvements](#performance-improvements)
- [Other improvements](#other-improvements)
- [Bug fixes](#bug-fixes)

## Devicetree editing improvements

We have made several quality-of-life improvements in this area, the most prominent of which are detailed below.

### Added include completion

Devicetree uses the C preprocessor to assemble its source files. Now, to help you find the right source files to include, we have added autocompletion for the preprocessor's `#include` directive.

![#include completion](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR151.gif "#include completion")

### Added code action for missing required properties

To help resolve warnings on nodes with missing required properties, we have added a code action for quickly adding all required properties missing from a devicetree node.
When applicable, a button with a light bulb icon will appear next to the selected node in the **Editor**. Click on this icon, and then **Add required properties** to have the missing required property added for you.

![Code action for missing properties](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR153.gif "Code action for missing properties")

### Added warning on children of disabled nodes

When adding devices to a bus, it is easy to miss whether the bus has been disabled in a board file. This kind of mistake is usually accepted by the build system, which will silently neglect linking in the corresponding drivers. To help prevent this issue, the extension will now emit a warning on all child nodes of disabled nodes in the **Editor**.

![Warning for children of disabled nodes](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR145.avif "Warning for children of disabled node")

### Insert semicolon after closing brace

VS Code is set up to automatically close any opening curly brackets in devicetree source files. While useful on its own, you would still need to go back and add a semicolon after the closing bracket, which defeats the purpose of the autoclosing bracket mechanism. The extension will now automatically insert a semicolon in addition to the closing bracket in all devicetree files.

![Add semicolon after brackets](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR152.gif "Add semicolon after brackets")

## Devicetree View improvements

We have added new actions to the **Devicetree View** and polished the existing ones.

### Enhancements to existing actions

We have done a lot of cleanup of the existing actions in the **Devicetree View**.

#### Moved nRF DeviceTree actions into submenu

To mirror similar changes in the **nRF Connect** extension, we have moved some of the actions with unintuitive icons or narrow use cases into a context menu on the various devicetree nodes.
Now, you can hover your cursor over the devicetree node and click on the  `...` button to access options in the submenu.

![Move Devicetree View options into context menu](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR170.avif "Move Devicetree View options into context menu")

#### Added icons to GPIO pins

As the **Unconnected** label on GPIO pins made the connected and unconnected pins hard to distinguish, we have removed this label, and replaced it with icons representing the connected or unconnected state of each pin. Filled-in icons represent a connected pin, and non-filled in icons represent an unconnected pin.

![GPIO pin icons](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR168.avif "GPIO pin icons")

#### Brought back bus node pins

With the move to `pinctrl`, the bus nodes' pin descriptions disappeared from the bus nodes.
They are now back for both old and new pin configuration schemes.

### New actions

We have also created new actions that will speed up your work with the **nRF DeviceTree** extension.

To access these actions:

1. Hover over a node.
    A "..." button appears to the right.
1. Click on the "..." to access **More actions...**.

1. Click on the desired option.

#### Add Alias

It is now possible to easily create devicetree aliases using the **Add Alias** option from the extended menu on the relevant nodes in the **Devicetree View**.

![Add Alias feature](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR167.avif)

#### Enable/disable toggle on interrupt requests

We have added the actions to enable or disable interrupt request (IRQ) nodes.

![Enable/disable toggle on IRQs](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR159.avif "Enable/disable toggle on IRQs")

#### Copy C Identifier for nodes and properties

We have added a **Copy C Identifier** submenu command to the devicetree nodes and properties that have C identifiers.
This option copies the C macro string to the clipboard, which can be pasted into an application's code.

![Copy C Identifier](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR156.gif "Copy C Identifier")

#### Edit interrupts

With the added **Edit Property Value** action, you can now edit the interrupt node that binds to the selected interrupt in order to change its priority.

![Edit property value](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR162.gif "Edit property value")

## Performance improvements

The previous release contained a regression that made the **nRF DeviceTree** extension's autocompletion take several seconds. Parsing and linting was also affected by this regression, causing severe performance issues in both startup time, autocompletion, and syntax validation.

The underlying regression has been addressed, along with some related performance bottlenecks.
Startup, parsing, and autocompletion should now take less than 50 ms, even for large devicetrees.

## Other improvements

We have also worked on several minor improvements to **nRF DeviceTree** behavior and UI.
Read about the most relevant ones below.

### Added file icons

We have added a file icon for devicetree files, to make it easier it identify these.

![Devicetree file icons](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR171.avif "Devicetree file icons")

### Reparsing all contexts on SDK changes

The extension now forces a full reparsing of all devicetree files when the SDK path changes.
This is to prevent **nRF DeviceTree** from pointing to old SDK paths in freestanding applications.

## Bug fixes

We have squashed several bugs, and here are the most relevant fixes.

### Addressed context issue when DeviceTree file is already open on startup

When VS Code was started (or restarted) with a devicetree file already in the active **Editor** area, the extension would fail to associate the file with the active build, thus disabling some of the editing features.

Now, the autocompletion and the **Devicetree View** should always be available for files opened on startup.

### Fixed deep binding inclusions being ignored

When binding inclusions were more than two layers deep, the logic for determining whether nodes belonged to a specific bus type or generic binding would fail. This would cause the extension to mistakenly label some bus nodes as invalid.

This problem is now addressed and all issues with bus nodes are being identified as they should.


---

# Version 2022.6.8

Welcome to the June 2022 release of nRF DeviceTree for VS Code.

## Added support for Nordic's `pinctrl` entries

nRF Connect SDK v2.0 introduces [DeviceTree Pin Control for configuring GPIO on Nordic devices](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/config_and_build/hardware/pin_control.html). These entries are now recognized by **nRF DeviceTree**, and will show up in the **GPIO** overview in the **Devicetree** panel.

## Added support for Zephyr updates

We have made updates to the extension for better support for recent Zephyr updates. The extension now:

* Supports integer suffixes used in C, such as `ULL`.
* Adds `include/zephyr` to the list of `include` directories to match the latest Zephyr updates with [header structure and usage](https://github.com/zephyrproject-rtos/zephyr/issues/41543).


---

# Version 2022.4.31

Welcome to the April 2022 release of nRF DeviceTree for VS Code.

## Diagnostics

In addition to the messaging the nRF Connect SDK build system provides for DeviceTree source files, the nRF DeviceTree extension displays additional warnings and suggestions to avoid common configuration issues and typos. Unfortunately, some of these warnings are triggered on system on chip (SoC) specific DeviceTree files in the nRF Connect SDK, which generally are not within the application developer's control. These warnings end up cluttering the VS Code diagnostics view, causing unnecessary noise for users.

Instead of showing these diagnostics for all applications, the extension will now only show DeviceTree diagnostics for the currently opened file. This provides more focused and relevant diagnostic information, whether you are contributing to the nRF Connect SDK or just working on your application.

## Environment

The nRF DeviceTree extension shares its execution environment with the nRF Connect extension if it is installed.
Whenever the nRF DeviceTree extension is running on its own, it attempts to locate the active nRF Connect SDK installation and other dependencies.
Unfortunately, this mechanism would misfire in some scenarios, causing unwanted notifications about missing `ZEPHYR_BASE` settings.
We have now corrected this.

## Sidebar tooltips

We have now improved the tooltip in the DeviceTree sidebar by adding informative text about what will happen if you click each entry, instead of just redundantly showing the entry label.

![Improved tooltip text for nRF DeviceTree](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/devicetree/screenshots/PR128.avif "Improved tooltip text for nRF DeviceTree")


---

# Version 2022.3.68

## Added

* Show unconnected pins in the treeview.
* Icon button to enable or disable a node from the treeview.
* Icon button to modify a property value from the treeview.
* Icon button to add a new node to a bus from the treeview.
* Icon button to delete a node with a `/delete-node/` statement from the treeview.
* Icon button to connect ADC channels from the treeview.
* Prompt user to create an overlay when attempting to edit a board file with commands.

## Updated

* Hide the **DeviceTree** panel in the Explorer view when in combination with the nRF Connect for VS Code extension.
* Skip parsing contexts at activation when the nRF Connect for VS Code extension is present.
* Record command usage using telemetry when the nRF Connect for VS Code extension is present and the user has opted in to telemetry.

## Fixed

* Include loops triggered by improper handling of include paths.
* Changed `required: true` to always takes precedence when merging type definitions.


---

# Version 2022.1.153

## General

### Updated

* **Show compiled output** now toggles between the compiled output and the source document.
* **Copy C Identifier** now includes named cells in phandles.
* The compiled output now provides symbol information and allows for Ctrl+Shift+O symbol searching.

## Bindings

### Updated

* Provided links for `.yaml` entries in the bindings files.
* Linked `compatible` property values to their corresponding bindings file.

## Code completion

### Added

* Completion suggestions for `const` properties.
* Completion suggestions for GPIO pins.

### Updated

* Provided more specific suggestions for the `compatible` property value based on the `bus` and `on-bus` bindings.
* Included references for the first position in phandle properties in completion suggestions.

### Fixed

* Defines are no longer suggested at the root level.
* **root** item suggestion is no longer preselected at the root level.
* Duplicate entries are no longer included in the `compatible` suggestions.
* Broken completion filtering for references.

## Lint

### Updated

* Warns if a node is missing the `compatible` property.
* Warns if the `compatible` value is unknown.
* Warns if a referenced node is missing the `okay` status.

### Fixed

* False warnings about nodes not being accepted on a bus are no longer displayed.


---

# Version 2021.12.6

## Code completion

### Updated

* Node snippet suggestions on the root node.

### Fixed

* Node snippets generated through code completion would only populate generic properties if the document was edited after the completion prompt showed up.

## Commands

### Updated

* Context-specific commands from the command palette are now hidden, as they would not work correctly when used outside the sidebar.
* Compiled output is now shown for the most recently opened context when there are no DeviceTree files opened.

### Removed

* Irrelevant shield commands.

## Lint

### Updated

* Scheduled lint runs are canceled whenever a file is changed to ensure linting does not run more than once on every version of the document.
* Node bindings are cached between every evaluation, making the lint process virtually instant.

## Parser

### Fixed

* Deleted nodes and properties are no longer shown in the processed output.
* How invalid `#undef` directive syntax are handled in the preprocessor.


---

# Version 2021.11.4

## Fixed

* Issue where UI commands would not execute.


---

# Version 2021.9.20

Initial release.
