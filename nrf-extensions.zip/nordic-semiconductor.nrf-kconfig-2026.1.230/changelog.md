# nRF Kconfig

The release notes for the extension are available in the [official documentation](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/rel_notes_overview.html).

# Version 2026.1.230

Welcome to the January 2026 release of the nRF Kconfig extension.

In this release, only minor improvements and bug fixes were implemented.


---

# Version 2025.8.117

Welcome to the August 2025 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

## Changes in 2025.9.123

### Bug fixes

- Fixed an issue on Windows where opening `Kconfig GUI` using the actions panel would sometimes result in the error "Unable to find Kconfig information." 

---

## [Problems View](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_panel.html#extension-related-issues-in-problems)

- Changed warning level to information when the source file that originates the warning is not in [active context](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts). 
- Removed Kconfig diagnostic entries about reassigning the same Kconfig option across different files. 

---

## Bug fixes

- Fixed an issue with starting Kconfig Language Server (Kconfig LSP) when menuconfig target is not available. 
- Fixed an issue with Kconfig being used in multiple builds using different SDKs in the same VS Code workspace. 
- Fixed an issue with the default path when using the **Save (minimal)** option. Now the default save path is under the application directory, not under the SDK. 


---

# Version 2025.4.26

Welcome to the April 2025 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

## General changes

- Added `def_*` syntax highlighting patterns to the Kconfig grammar. 


---

# Version 2024.12.13

Welcome to the December 2024 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

## General changes

* Changed the fallback of Python for the language server to the toolchain of the [active build](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts) instead of the system. 
* Added support for board definitions that use `extend`. 

---

## Bug fixes

* Fixed an issue with providing C/C++ include diagnostics. 
* Fixed an issue with passing `\_defconfig` file to the Kconfig context. 


---

# Version 2024.11.16

Welcome to the November 2024 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

## General changes

* Allowed using Python v3.12.x for the language server. 
* Added support for using the `build_info.yml` file to read build information. 


---

# Version 2024.9.20

Welcome to the September 2024 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

---

## [nRF Kconfig GUI](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_kconfig.html)

- Added support for [Hardware Model v2](https://docs.nordicsemi.com/bundle/ncs-latest/page/zephyr/hardware/porting/board_porting.html#transition_to_the_current_hardware_model).
- Added a mechanism for updating the active [build context](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_applications.html#application-contexts) between the nRF Connect, the nRF DeviceTree, and the nRF Kconfig extensions. 
- Fixed an issue with opening the Kconfig GUI for builds with shields. <span title="This change was suggested by a user!">💬</span> 

---

## [Kconfig language support](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/ncs_configure_app.html#kconfig-overview)

- Added the reactivation of the Kconfig language server when the SDK or the toolchain changes. 
- Fixed malformation issues of Kconfig options related to Sysbuild. 

---

## Diagnostics

- Added a mechanism for clearing the diagnostics of the non-active contexts. 
- Improved the command diagnostic mechanism to make the warnings appear more consistently. 
- Fixed duplicated command diagnostics. 

---

## Known issues

We are aware of the following known issues that affect this release of the extension.

### Visual Studio Code does not detect all files used by a build

In some cases, especially for build configurations that use sysbuild or shields (or both), some Kconfig files (`.conf`) are not picked up by the active build context.
This issue has the following consequences:

* The devicetree language server will be unaware of the context of these files when computing results.
* The Devicetree Visual Editor will render an incomplete state for that context.
* Tooltips will not be shown for these files.


---

# Version 2024.2.71

Welcome to the February 2024 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

## Fixes in 2024.3.21

* Added missing Kconfig values to builds in LSP. 
* Fixed an issue with committing unchanged values from `onBlur()` events. 

----

* Added `APPLICATION_SOURCE_DIR` and `TOOLCHAIN_HAS_NEWLIB` to the environment passed to menuconfig. <span title="This change was suggested by a user!">💬</span> 
* Fixed an error message that would show whenever the `CMakeCache.txt` file was deleted. 


---

# Version 2023.11.64

Welcome to the November 2023 release of the nRF Kconfig extension.

Read below for the summary of the most important changes.

---

## nRF Kconfig GUI

* Added the [**Reset Value**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_kconfig.html#treeview) button that resets the option to its original value.
* Changed the icon of the [**Jump to Item**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_kconfig.html#changes-list) button to avoid confusion with the reset button.
* Added [context menu](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_kconfig.html#treeview-context-menu-actions) for treeview items.
* Clicking on the expand chevron in the treeview now toggles the option's expanded state on the first click.
* Added a checkbox to optional radio groups.
* Fixed a glitch in the active item selection when pressing a radio button.

---

## Kconfig language support

* Added parsing, syntax highlighting, and auto-completion support for `configdefault`, introduced in [Zephyr PR #51316](https://github.com/zephyrproject-rtos/zephyr/pull/51316).
* Fixed a broken inline hint for the configuration settings that are set in `prj.conf`, but end up being excluded from the final build.
* Fixed the incorrect error highlighting of `if` after `imply`.

---

## Zephyr header file suggestions

* Added Zephyr's subsystem configuration options to the header file checker.


---

# Version 2023.9.31

Welcome to the September 2023 release of the nRF Kconfig extension.

This release, we have been working on improving the following areas:

- [nRF Kconfig GUI](#nrf-kconfig-gui)
- [Language server changes](#language-server-changes)

## Changes in 2023.9.94

- Bumped the minimum Python version to v3.7 to resolve a crash.
- Fixed the syntax highlighting for `if` conditions on `imply` entries.
- Changed **Go to Definition** and **Jump to Item** icons to more intuitive ones.
- Fixed an issue where the Kconfig menu search would be reopened when interacting with the main menu.

## nRF Kconfig GUI

### "Go to definition" button

We've added a button to the Kconfig symbols that when clicked will take you to the line in the Kconfig file where the symbol was defined.

### Show documentation in Kconfig UI when node is clicked <span title="This change was suggested by a user!">💬</span>

Today, clicking the **Information** icon in the right-hand side of a node will show its documentation. We've had feedback that this icon was easy to miss, so in this release the behavior has been changed to show the node documentation when anywhere in the node is clicked.

### Fuzzy search scores

The behavior for fuzzy search of symbols was adjusted to increase the score awarded for consecutive letters. This means keywords such as `MPU` and `CPU` will be ranked higher.

## Language server changes

* The language server is now notified when new configuration files are added to the active build.
* Zephyr drivers have been added to the list of resolved header files.
* A new code action will appear when including a header file that requires a Kconfig parameter to be set. Through the code action, the nRF Kconfig GUI will automatically open to the correct symbol, allowing any necessary changes to be made.


---

# Version 2023.6.51

Welcome to the June 2023 release of the nRF Kconfig extension.

This release, we have been working on improving the following areas:

- [Support for sysbuild](#support-for-sysbuild)
- [Disabled save to non-existing file](#disabled-save-to-non-existing-files)

## Support for sysbuild

With the introduction of Zephyr's [sysbuild](https://docs.nordicsemi.com/bundle/ncs-2.4.0/page/zephyr/build/sysbuild/index.html) to the nRF Connect SDK and to the [nRF Connect extension](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/build_overview.html#system-build-sysbuild), the nRF Kconfig extension needed a few tweaks to support all the new mechanisms. The extension now automatically detects whether the build configuration is based on sysbuild or is a traditional Zephyr build. It also adjusts accordingly the Kconfig menu and the Kconfig and `.conf` files.

---

## Disabled save to non-existing files

The [**Save to file**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/guides/work_with_kconfig.html#how-to-save-kconfig-changes) button allows you to write configuration changes to the active `prj.conf` file. In some scenarios, no such file exists, and the button produces an error when clicked. For example, this is common when editing build configurations that use sysbuild. We have shortened the feedback loop by disabling the button in such cases.


---

# Version 2023.4.17

Welcome to the April 2023 release of the nRF Kconfig extension.

This release, we have been working on improving the following areas:

- [nRF Kconfig GUI: Renamed Save to Apply](#nrf-kconfig-gui-renamed-save-to-apply)
- [Editing](#editing)
- [Housekeeping](#housekeeping)

## nRF Kconfig GUI: Renamed Save to Apply

To avoid confusion, the **Save** button in [nRF Kconfig GUI](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_kconfig.html) has been renamed to **Apply**. This button applies the changes you have made through the GUI to the active configuration file, and is the correct choice when you simply want to change configuration options in your build configuration.

![Save renamed to Apply](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR2281.avif)

---

## Editing

We have corrected some issues with the Kconfig editing experience, primarily centered around context management.

### Stopped reparsing broken Kconfig contexts

Kconfig contexts that have failed compilation are no longer reparsed until a change is detected in their files. This prevents the same failure diagnostic appearing multiple times.

### Kconfig GUI reloads on save

The Kconfig GUI's treeview now reloads whenever a Kconfig file that is part of the active build is saved to disk.

### Improved stability and error recovery

We applied the following changes to improve stability and error recovery:

* The Kconfig tree is now reparsed more often.
* Fixed a cascading crash that could occur on import.
* Fixed an error that could occur when checking if Python files are in Zephyr on Windows.

### Account for ZEPHYR_BASE changes in module reload

When switching between different nRF Connect SDK installations, the Kconfig language service could fail to load the ``kconfigfunctions`` module from the correct Zephyr repository. As a result, this could cause errors with the ``dt_`` macros in Kconfig files that wouldn't appear with the build system. The extension now ensures that the correct module is imported.

---

## Housekeeping

* The minimum required version of VS Code has been increased to v1.66.


---

# Version 2022.11.50

Welcome to the November 2022 release of the nRF Kconfig extension.

We rely on feedback from our users to make the VS Code extensions as useful and stable as possible. Each release includes several features and bug fixes suggested by our users. We highlight these changes with a dedicated tag in the release notes: <span title="This change was suggested by a user!">💬</span>

If you have any suggestions for new features or bugs that need fixing, you can submit them through the extension's [built-in feedback form](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_welcome.html#toolbar-actions) or the [Nordic DevZone](https://devzone.nordicsemi.com/)

## Kconfig tasks run in the default shell <span title="This change was suggested by a user!">💬</span>

We added a setting in the nRF Connect for VS Code > Extension settings to change the default shell where Kconfig tasks are run.
Kconfig tasks are executed in the Command Prompt, on some Windows machines. This would cause errors in some environments, but now this setting is added to let run Kconfig tasks in the default shell.

## nRF Kconfig GUI scroll when jumping to an item

We fixed a bug where the nRF Kconfig GUI's tree would not always scroll to an item when jumped to from the search bar.


---

# Version 2022.9.15

Welcome to the September 2022 release of the nRF Kconfig extension for VS Code.

* **Original release version:** v2022.9.15

In this release, we worked on improving the following areas:

- [Shield support](#shield-support)
- [Properties file recognition](#properties-file-recognition)
- [Bug fixes](#bug-fixes)

## 2022.10.7 additionally fixes the following issues:

* **nRF Kconfig GUI:** When toggling boolean options the UI would switch the active entry for a split second, causing a glitch in the breadcrumbs view and selection highlight.

## Shield support

nRF Kconfig now supports [Zephyr shields](https://docs.zephyrproject.org/latest/hardware/porting/shields.html). The extension can find and include Zephyr shield configuration files for an application's build.

## Properties file recognition

`_defconfig` files, such as `nrf52dk_nrf52832_defconfig`, in the nRF52 development kit directory are now recognized as properties files. This enables syntax highlighting and other language features for these files.

## Bug fixes

We fixed a bug where the extension would incorrectly show a warning in general parsing cases. This warning has now been disabled for these cases.

Additionally, we fixed an uncommon bug in the **nRF Kconfig GUI** that would cause the extension to crash. This bug would occur when switching between the **Change** and **Edit** tabs when a search was in progress.


---

# Version 2022.7.24

Welcome to the July 2022 release of nRF Kconfig for VS Code.

In this release, we have been working on improving the following areas:

- [nRF Kconfig GUI search](#nrf-kconfig-gui-search)
- [File associations](#file-associations)
- [Extension configuration](#extension-configuration)

## nRF Kconfig GUI search

Based on the feedback we received, we have made some adjustments and fixes to the **nRF Kconfig GUI** search functionality.

### Removed prompt/ID filtering based on query format

We removed the search query filtering based on the query formatting, as this mechanism was too unpredictable. Now, all queries will match against both the prompt and the configuration ID, except if the query starts with `CONFIG_`.

### Jump to invisible items

Previously, jumping to a hidden item from the search didn't toggle the **Show hidden items** button, so the item did not show up in the main menu when navigated to from the search. Now, showing hidden items will be turned on automatically when you navigate to an invisible item.

### Small enhancements

We have made a number of small enhancements to the **nRF Kconfig GUI**:

* Hovering over an item in the breadcrumbs at the top of the GUI now shows the full name of the item.
* When clicking items in the breadcrumbs at the top of the GUI, the view now scrolls to that item instead of just selecting it.
* The search bar now shows an indicator animation when searching.
* It's now possible to jump to the search bar using either Ctrl-L or Ctrl-F.
* History can now be navigated using the side buttons available on some mouses.

### Minor bug fixes

Additionally, we have fixed several small bugs in the **nRF Kconfig GUI**:

* Keyboard shortcuts did not work in some cases when searching for an item.
* Keyboard shortcuts allowed expanding non-expandable checkboxes.
* When searching, the path displayed in the result bar only showed the original value. If you searched for another item, the result bar did not update.

## File associations

To make working with Kconfig files in VS Code easier, we have made some enhancements to the way VS Code renders and recognizes these files.

### Kconfig file icons

Earlier this year, VS Code added support for [setting default file icons for languages](https://code.visualstudio.com/updates/v1_64#_language-default-icons). These icons will now show up both in the file explorer and the tab list for Kconfig files.

![Kconfig file icons](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR223.avif "Kconfig file icons")

### Recognize all Kconfig files

Previously, only files named "Kconfig" and a few other common names would be recognized as Kconfig files. Other file names would previously be assigned a language dynamically, but with the addition of VS Code's [automatic language detection](https://code.visualstudio.com/updates/v1_60#_automatic-language-detection). This caused the extension's ability to dynamically recognize Kconfig files to be lost.
We have tweaked the language definition slightly for this release to ensure that all Kconfig files would be recognized automatically, regardless of their suffix.

### Status Bar notification for the project's .conf files not in context

If a project configuration file (such as a `prj.conf` file or similar) is in the active **Editor** window that does not belong to the active build configuration, then Kconfig features like completion, hover, and suggestions would not work or would be limited. To make it easier to determine when this happens, we have added a **Status Bar** message in orange that will warn you when the open configuration file is not part of the active build.

![Kconfig: no context warning](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR213.avif "Kconfig: context warning")

## Extension configuration

We have done a review of the extension's configuration entries, and have updated the help text.

Additionally, we have removed the following configuration options, as they are no longer in use:

- `kconfig.env`
- `kconfig.root`
- `kconfig.cfiles`
- `kconfig.disable`


---

# Version 2022.6.2

Welcome to the June 2022 release of nRF Kconfig for VS Code. This release, we have been working on improving the following areas:

- [Kconfig syntax highlighting](#kconfig-syntax-highlighting)
- [nRF Kconfig GUI improvements](#nrf-kconfig-gui-improvements)
- [New GUI buttons](#new-gui-buttons)
- [Search improvements](#search-improvements)
- [Bug fixes](#bug-fixes)

## Kconfig syntax highlighting

### Added macros to syntax grammar definition

We extended the Kconfig syntax grammar to understand and highlight macros, making them easier to identify in your Kconfig files.

![Added macros to syntax grammar definition](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR200.avif "Added macros to syntax grammar definition")

### Highlight negative numbers

We fixed an issue where numbers such as `1 242 0x33af3d` would be highlighted but not their negative values, for example `-1 -242 -0x33af3d`. Both types of values are now correctly highlighted.

## nRF Kconfig GUI improvements

### Keep the nRF Kconfig tree state when switching tab views

Previously, your position in the tree would be lost when switching to the **Changes** tab. This meant you had to re-expand all the nodes each time. We now save the expanded items when you switch between the **nRF Kconfig** and **Changes** tabs, and restore the previous state whenever you switch back.

### Fixed the keyboard navigation in the Kconfig tree view

In the **nRF Kconfig GUI** menu, the keyboard Up and Down arrow buttons now let you move the menu's scroll position so you can focus on the menu items more intuitively.

### Add links to dependency names in the description box

Dependency names for Kconfig options now include links in the description box that display available information about that dependency.

![Link to symbol names](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR184.gif "Links to symbol names")

### Show the parent item of a searched item

Previously, when a parent item was disabled or invisible in the nRF Kconfig tree view, the child items could not be seen or accessed from the search result tree. Now all parent and child items are displayed.

### Display 'No visible children' item for relevant tree nodes

If a menu is expanded and it has no child items, we now show a message that says, "No visible children" in greyed-out text to help you keep better track of your project's Kconfig options.

## New GUI buttons

### Forward and backward navigation buttons

The **nRF Kconfig GUI** now supports history navigation so you can move forward and backward between different GUI states. This allows you to easily recover your position in situations like jumping to a symbol from the searches results.

![History navigation buttons](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR193.avif "History navigation buttons")

### Added a button to show hidden nodes

You now have the option to show or hide hidden nodes for Kconfig options. Using the icon in the top right corner, you can toggle between **Show Hidden Items** and **Don't Show Hidden Items**.

![Hidden nodes button](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR192.gif "Hidden nodes button")

Read more about this feature in the [General features](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_kconfig.html) section of the **nRF Kconfig** documentation.

## Search improvements

### Sublime text fuzzy search

We have improved fuzzy searches by implementing a fuzzy search algorithm as described by Forrest Smith in [ForrestTheWoods](https://www.forrestthewoods.com/blog/reverse_engineering_sublime_texts_fuzzy_match/).

The fuzzy search will now be applied to both the ID and the prompt of the configuration options, with some exceptions:

- Searches starting with `CONFIG_` and searches consisting only of upper case letters and underscores will only match against IDs.
- Searches with spaces will only match against prompts.

## Bug fixes

### Release files on parser errors

The Kconfig language server would occasionally fail to release file handles when encountering Kconfig errors, causing the file to be locked in the OS, blocking git checkouts and other write operations. This has now been fixed.

### Stay on a checkbox item after toggling with keyboard shortcuts

We fixed an issue in the search view where a checkbox item would lose focus after being toggled with keyboard shortcuts. It is now easier for you to toggle back and forth between different states of the **nRF Kconfig GUI**.


---

# Version 2022.4.55

Welcome to the April 2022 release of nRF Kconfig for VS Code.

## Configuration files

An error message will now display when an unknown symbol is used in configuration files.

## Source file code actions

Kconfig symbols are referenced throughout the nRF Connect SDK's source files to configure various aspects of the codebase. To support a workflow where you want to make changes to the referenced Kconfig symbol in your build, we have added some [Code Actions](https://code.visualstudio.com/docs/editor/refactoring) directly in the source files.

To access Code Actions for Kconfig symbols, place your cursor on a `CONFIG_XYZ` symbol in a C or C++ source file and press the light bulb icon on the left-hand side of the editor.

In this release, we have added two types of Code Actions for Kconfig symbols to C and C++ files:

### Change symbol values

Boolean and choice options can now be changed from the source files, and any changes will take effect immediately, updating both the IntelliSense configuration and the active build's configuration itself.

![Source file code actions](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR166.gif "Source file code actions")

This action is equivalent to changing the relevant symbol in the **nRF Kconfig GUI** or menuconfig and pressing "Save", then rebuilding. Note that the changes made through these Code Actions are not committed to your configuration files, only to your active build.

### Open symbols in the nRF Kconfig GUI

Symbols that are accessible in the **nRF Kconfig GUI** can be opened though a Code Action. Note that you can only open [visible symbols](https://docs.nordicsemi.com/bundle/ncs-1.9.1/page/zephyr/guides/build/kconfig/setting.html#visible_and_invisible_kconfig_symbols) in the **nRF Kconfig GUI**.

This action is most useful for string and integer symbols, or if you want to commit your changes to a configuration file.

## nRF Kconfig GUI

We improved highlighting in the menu to help you focus on selected symbol options.

![Kconfig item highlighting](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR163.avif "Kconfig item highlighting")

Search results in the **nRF Kconfig GUI** are now grouped by their parent item to make it easier to understand their context within the overall Kconfig tree.

![Kconfig search grouped by parent item](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR164.avif "Kconfig search grouped by parent item")

We added a cog wheel icon into the nRF Kconfig GUI webview tab so that you can quickly locate the screen when you have multiple tabs open.

![Kconfig webview tab icon](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/release_notes/kconfig/screenshots/PR165.avif "Kconfig webview tab icon")

## Other improvements

We fixed an issue where the Kconfig language server could crash if a configuration file was included in the build, but unknown to VS Code. The issue would manifest as an error notification with the text "AttributeError: 'NoneType' object has no attribute 'mtime'"


---

# Version 2022.1.78

## Added

* `Save to file` functionality that saves a minimal config for the current Kconfig state to the active `prj.conf`.
* Line decoration in Kconfig files, which shows the live state if it is different to the current value.
* Symbol dependencies to the **nRF Kconfig GUI** description panel.
* Indent guidelines in the tree view for visual clarity.
* Various styling improvements to the **nRF Kconfig GUI**.

## Fixed

* Nodes no longer expand in the **Changes** view.
* Disabled menus no longer expand.
* Horizontal and vertical splitter movements impacting each other in the **nRF Kconfig GUI**.
* Language server code not reloading with the west workspace.

## Removed

* Top level of the **nRF Kconfig GUI** tree view.


---

# Version 2021.12.174

## Added

* Kconfig editing interface.
* Status bar item to show the status of the language server.

## Updated

* Completion results for C and Kconfig files.

## Fixed

* Windows URI comparisons are now case insensitive.
* Context URL is now parsed through `Uri.parse`.
* Overlay configs are now picked up from `cmakecache`.
* `CONFIG_ABC=n` is now explicitly written in minimal config.


---

# Version 2021.12.60

## Added

* Python executable selection setting.
* Support for all environment variable formats in Kconfig files.
* Backtrace info in the error output from the language server.

## Fixed

* A Python version check is now performed before starting the language server to show human-readable error messages.
* Reduced LSP file events.
* Only `glob` for all builds if the main nRF Connect for VS Code extension isn't installed.
* Snippet insertions for boolean values with no valid options.
* Unicode symbols in files and the environment are now supported.
* The `MODULE_EXT_DIR` mechanism in west modules is now supported, which fixes issues with Kconfig symbols in some modules not discovered by the language server.
* Handling Windows URIs is now normalized to prevent formatting mismatches for build directories.


---

# Version 2021.11.7

This release replaces the proprietary Typescript-based Kconfig parser with a Python-based Language Server back-end for the Kconfig language, and is built on top of the Kconfig library used by Zephyr.


---

# Version 2021.9.10

Initial release.
