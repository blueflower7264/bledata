# Copyright (c) 2021 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: LicenseRef-Nordic-1-Clause

import os
from typing import Union
import kconfiglib as kconfig
from lsp import Location, Position, Uri


def conf_string(sym: kconfig.Symbol, prefix):
    """
    Return the symbol's current value, as it should look in a prj.conf file.

    This is different from sym.config_string, which is meant to be inserted into
    the output file. It may generate comments in some cases.
    """
    if sym.orig_type == kconfig.STRING:
        value = f'"{sym.str_value}"'
    else:
        value = sym.str_value

    return f'{prefix}{sym.name}={value}'


def loc(sym: kconfig.Symbol):
    """Get a list of locations where the given kconfig symbol is defined"""
    return [
        Location(
            Uri.file(os.path.join(n.kconfig.srctree, n.filename)),
            Position(n.linenr - 1, 0).range,
        )
        for n in sym.nodes
    ]


def get_prompt(sym: Union[kconfig.Symbol, kconfig.Choice], ignore_expr=False):
    """
    Get the most accessible prompt for a given kconfig Symbol.

    Each symbol may have multiple prompts (as it may be defined in several kconfig files).
    Pick the first valid prompt.

    This'll only consider prompts whose if expressions are true.
    """
    for node in sym.nodes:
        if node.prompt and (ignore_expr or kconfig.expr_value(node.prompt[1])):
            return node.prompt[0]
