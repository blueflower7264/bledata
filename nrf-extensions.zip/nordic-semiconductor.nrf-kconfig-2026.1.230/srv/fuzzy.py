# Copyright (c) 2022 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: LicenseRef-Nordic-1-Clause

"""
Fuzzy search implementation, based on
https://www.forrestthewoods.com/blog/reverse_engineering_sublime_texts_fuzzy_match/
"""


from typing import Callable, Iterable, List, Optional, Tuple, TypeVar, cast


def _normalize(text: str) -> str:
    return text.lower().replace('_', ' ').strip()


def _score(pattern: str, item: str) -> Tuple[bool, int]:
    UNMATCHED = -1
    CONSECUTIVE = 10
    SEPARATOR = 5
    LEADING = -3
    FIRST_LETTER_BONUS = 5
    MAX_LEN = 1000

    score = 0
    first_match = True
    prev = False
    matched = False
    item_word = False
    pattern_word = False
    p = 0
    i = 0
    while p < len(pattern) and i < len(item):
        if item[i] == ' ':
            item_word = True
            i += 1
            continue
        if pattern[p] == ' ':
            pattern_word = True
            p += 1
            continue

        matched = pattern[p] == item[i]
        if matched:
            if first_match:
                first_match = False
                score += min(3, i) * LEADING
                if i == 0:
                    score += FIRST_LETTER_BONUS
            elif prev:
                score += CONSECUTIVE

            if item_word:
                score += SEPARATOR
                # Additional bonus if the pattern had a space here too:
                if pattern_word:
                    score += SEPARATOR

            p += 1
        else:
            score += UNMATCHED

        prev = matched
        item_word = False
        pattern_word = False
        i += 1

    # Use inverse item length as a tie breaker, assuming no word is longer than MAX_LEN.
    # This ensures that exact matches are preferred over matches where the whole pattern
    # is a substring of the item
    return (p == len(pattern), score * MAX_LEN - len(item))


def fuzzy_search(pattern: str, items: Iterable[str]) -> List[Tuple[bool, int]]:
    pattern = _normalize(pattern)

    return [max(_score(pattern, part) for part in _normalize(item).split(',')) for item in items]


T = TypeVar('T')


def fuzzy_sort(
    pattern: str, items: Iterable[T], key: Optional[Callable[[T], str]] = None
) -> List[T]:
    """
    Get a list of all matches, ranked from best to worst.

    The items must either be a list of strings, or key must be set to a transform function
    that pulls the search string from each item.

    Returns the matching items in decreasing order of relevance.
    """
    if key is None:
        mapped_items = cast(List[str], items)
    else:
        mapped_items = [key(i) for i in items]

    result = fuzzy_search(pattern, mapped_items)
    zipped = sorted(
        ((item, score) for item, (found, score) in zip(items, result) if found),
        key=lambda r: r[1],
        reverse=True,
    )

    return [item for item, _ in zipped]


__all__ = ['fuzzy_search', 'fuzzy_sort']
