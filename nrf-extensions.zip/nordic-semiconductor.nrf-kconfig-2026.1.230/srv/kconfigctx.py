# Copyright (c) 2021 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: LicenseRef-Nordic-1-Clause

from __future__ import annotations
from datetime import datetime
import enum
from typing import NamedTuple, Optional, List, Dict, Tuple, Union, cast
import importlib
import kconfiglib as kconfig
import sys
import os
import re
from fuzzy import fuzzy_sort
from rpc import RPCError
from lsp import (
    CodeAction,
    Command,
    Diagnostic,
    Position,
    Location,
    TextEdit,
    Uri,
    TextDocument,
    Range,
    DocumentStore,
)
from symbols import conf_string, get_prompt

ID_SEP = '@'
KCONFIG_WARN_LVL = Diagnostic.WARNING
KCONFIG_INFORMATION_LVL = Diagnostic.INFORMATION
KCONFIG_HINT_LVL = Diagnostic.HINT
TO_OP = {kconfig.AND: '&&', kconfig.OR: '||', kconfig.NOT: '!', **kconfig.REL_TO_STR}


def _filter_match(filter: str, name: str):
    """Filter match function used for narrowing lists in searches and autocompletions"""
    return filter in name  # TODO: implement fuzzy match?


def _missing_deps(sym):
    """
    Get a list of the dependency expressions that fail for a symbol
    """
    deps = kconfig.split_expr(sym.direct_dep, kconfig.AND)
    return [dep for dep in deps if kconfig.expr_value(dep) == 0]


def _children(node):
    """Get the child nodes of a given MenuNode"""

    def get_children(node: kconfig.MenuNode):
        children: List[kconfig.MenuNode] = []
        node = cast(kconfig.MenuNode, node.list)
        while node:
            children.append(node)
            node = cast(kconfig.MenuNode, node.next)
        return children

    if isinstance(node.item, kconfig.Choice):
        # Choices may be appended to in multiple locations.
        # For ease of use, gather all options added to this choice, so users
        # can see all valid option in every location.
        # See menuconfig.py's _shown_nodes for additional info.
        choice: kconfig.Choice = node.item
        children = []
        # Gather the current node's symbols first, so those are preferred when the symbol
        # is added in multiple places:
        symbols = {n.item for n in get_children(node) if isinstance(n.item, kconfig.Symbol)}

        for choice_node in choice.nodes:
            for child in get_children(choice_node):
                if not isinstance(child.item, kconfig.Symbol):
                    children.append(child)
                elif child.item not in symbols or choice_node is node:
                    children.append(child)
                    # Only show each symbol once:
                    symbols.add(child.item)

        return children

    return get_children(node)


def _direct_dep_info(sc, ctx):
    # Returns a string describing the direct dependencies of 'sc' (Symbol or
    # Choice). The direct dependencies are the OR of the dependencies from each
    # definition location. The dependencies at each definition location come
    # from 'depends on' and dependencies inherited from parent items.

    if sc.direct_dep is ctx._kconfig.y:
        return {"type": "direct"}
    else:
        return {
            "type": "expression",
            "value": kconfig.TRI_TO_STR[kconfig.expr_value(sc.direct_dep)],
            "ast": to_expr_ast(sc.direct_dep),
        }


# Copied from the guiconfig implementation
def _expr_str(expr):
    # Custom expression printer that shows symbol values
    return kconfig.expr_str(expr, _name_and_val_str)


# Copied from the guiconfig implementation
def _is_num(name):
    # Heuristic to see if a symbol name looks like a number, for nicer output
    # when printing expressions. Things like 16 are actually symbol names, only
    # they get their name as their value when the symbol is undefined.

    try:
        int(name)
    except ValueError:
        if not name.startswith(("0x", "0X")):
            return False

        try:
            int(name, 16)
        except ValueError:
            return False

    return True


# Initially copied from the guiconfig implementation and adjusted to return a dictionary
def _name_and_val_str(sc):
    # Custom symbol/choice printer that shows symbol values after symbols

    # Show the values of non-constant (non-quoted) symbols that don't look like
    # numbers. Things like 123 are actually symbol references, and only work as
    # expected due to undefined symbols getting their name as their value.
    # Showing the symbol value for those isn't helpful though.
    if isinstance(sc, kconfig.Symbol) and not sc.is_constant and not _is_num(sc.name):
        if not sc.nodes:
            # Undefined symbol reference
            return {
                'name': sc.name,
                'value': 'undefined/n',
                'visible': bool(_node_with_prompt(sc)),
            }

        return {'name': sc.name, 'value': sc.str_value, 'visible': bool(_node_with_prompt(sc))}

    # For other items, use the standard format
    if isinstance(sc, kconfig.Symbol):
        return {
            'name': kconfig.standard_sc_expr_str(sc),
            'visible': bool(_node_with_prompt(sc)),
        }
    else:
        return {'name': kconfig.standard_sc_expr_str(sc), 'visible': True}


def _node_with_prompt(sym: kconfig.Symbol) -> Optional[kconfig.MenuNode]:
    """Get the first MenuNode with a prompt this symbol has"""
    return next(
        (node for node in cast(List[kconfig.MenuNode], sym.nodes) if node.prompt),
        None,
    )


def _suboption_depth(node):
    """In menuconfig, nodes that aren't children of menuconfigs are rendered
    in the same menu, but indented. Get the depth of this indentation.
    """
    parent = node.parent
    depth = 0
    while parent and not parent.is_menuconfig:
        depth += 1
        parent = parent.parent
    return depth


def _visible(node: kconfig.MenuNode):
    """Check whether a node is visible."""

    def node_is_visible(n: kconfig.MenuNode):
        return (
            n.prompt
            and kconfig.expr_value(n.prompt[1])
            and not (n.item == kconfig.MENU and not kconfig.expr_value(cast(bool, n.visibility)))
        )

    if node_is_visible(node):
        return True

    # Also mark nodes as visible if they have visible children:
    # Sometimes, there are multiple successive nodes for the same symbol, but they have different
    # visibility rules. If the last node is followed by an "if NODE" statement, the next nodes
    # will be children of the last NODE. In these cases, we'll want to render the last node
    # (and its children), since the children are technically supposed to be visible.
    if isinstance(node.item, kconfig.Symbol):
        children = _children(node)
        if next((child for child in children if node_is_visible(child)), None):
            return True

    return False


def normpath(path: str) -> str:
    path = os.path.normpath(path)

    # drive letters are randomly capitalized on windows:
    if sys.platform == 'win32':
        path = path.capitalize()
    return path


def to_expr_ast(expr):
    if isinstance(expr, tuple) and len(expr) == 3:
        return {
            "type": "binary",
            "op": TO_OP[expr[0]],
            "left": to_expr_ast(expr[1]),
            "right": to_expr_ast(expr[2]),
        }
    elif isinstance(expr, tuple) and len(expr) == 2:
        # Just the 'not' operator
        return {
            "type": "unary",
            "op": TO_OP[expr[0]],
            "expr": to_expr_ast(expr[1]),
        }
    else:
        return {"type": "node", **_expr_str(expr)}


class MenuItem:
    """
    Single menu item in a tree, search or diff list.
    """

    @staticmethod
    def from_sym(ctx: KconfigContext, sym: kconfig.Symbol) -> Optional['MenuItem']:
        """
        Create a MenuItem from a kconfig Symbol, based on the most appropriate menu node.
        """
        # Pick a node with a prompt, but don't check whether the prompt is visible:
        node = _node_with_prompt(sym)
        if node:
            return MenuItem(ctx, node)
        return None

    def __init__(self, ctx: KconfigContext, node: kconfig.MenuNode):
        sym = cast(Union[kconfig.Symbol, kconfig.Choice, int], node.item)
        self.visible = _visible(node) != 0
        self.loc = Location(
            Uri.file(os.path.join(ctx.env['ZEPHYR_BASE'], cast(str, node.filename))),
            Position(cast(int, node.linenr) - 1, 0).range,
        )
        self.isMenu = node.is_menuconfig
        self.hasChildren = node.list != None or isinstance(sym, kconfig.Choice)
        self.depth = _suboption_depth(node)
        self.id = ctx._node_id(node)
        if isinstance(sym, kconfig.Symbol) or isinstance(sym, kconfig.Choice):
            self.dependencyInfo = _direct_dep_info(node.item, ctx)

        # Get the menu path leading to this node as a list of menuNode IDs:
        parent: Optional[kconfig.MenuNode] = node.parent
        path = []
        while parent:
            path.append(ctx._node_id(parent))
            parent = parent.parent

        self.path = list(reversed(path))

        if node.prompt:
            self.prompt = node.prompt[0]

        if hasattr(node, 'help') and node.help:
            self.help = node.help

        if sym == kconfig.COMMENT:
            self.kind = 'comment'
        elif sym == kconfig.MENU:
            self.kind = 'menu'
        elif not isinstance(sym, int):
            self.name = sym.name
            self.type = kconfig.TYPE_TO_STR[sym.orig_type]
            if hasattr(sym, 'assignable') and sym.assignable:
                self.options = list([kconfig.TRI_TO_STR[val] for val in sym.assignable])

            if isinstance(sym, kconfig.Symbol):
                self.kind = 'symbol'
                self.val = sym.str_value
                self.changed = (
                    self.val != ctx.original_values.get(sym.name, self.val) if sym.name else False
                )
                self.originalVal = (
                    ctx.original_values.get(sym.name, sym.str_value) if sym.name else sym.str_value
                )

            if isinstance(sym, kconfig.Choice):
                self.kind = 'choice'
                self.optional = sym.is_optional
                if sym.selection:
                    self.val = get_prompt(sym.selection)
                else:
                    # This is an optional choice:
                    self.val = None
        else:
            self.kind = 'unknown'


class DiffMenuItem(MenuItem):
    """
    MenuItem with originalValue attached
    """

    def __init__(self, ctx: 'KconfigContext', node: kconfig.MenuNode):
        super().__init__(ctx, node)
        sym = cast(Optional[kconfig.Symbol], node.item)
        if isinstance(sym, kconfig.Symbol):
            self.original = ctx.default[sym.name] if sym.name in ctx.default else None

    @staticmethod
    def from_sym(ctx: 'KconfigContext', sym: kconfig.Symbol) -> Optional['DiffMenuItem']:
        """
        Create a DiffMenuItem from a kconfig Symbol, based on the most appropriate menu node.
        """
        # Pick a node with a prompt, but don't check whether the prompt is visible:
        node = _node_with_prompt(sym)
        if node:
            return DiffMenuItem(ctx, node)
        return None


class KconfigMenu:
    def __init__(self, ctx: KconfigContext, node: kconfig.MenuNode, id: str):
        """
        A single level in a Menuconfig menu.
        """
        self.ctx = ctx
        self.node = node
        self.id = id
        self.items = [MenuItem(self.ctx, node) for node in _children(self.node) if node.prompt]

    @property
    def name(self) -> Optional[str]:
        if self.node.prompt:
            return self.node.prompt[0]
        return None

    def to_dict(self):
        return {
            'name': self.name,
            'id': self.id,
            'items': self.items,
        }


class KconfigFileTreeItem:
    def __init__(self, path: str, hasChildren: bool) -> None:
        self.path = path
        self.hasChildren = hasChildren


class ConfEntry:
    def __init__(self, name: str, loc: Location, assignment: str, value_range: Range):
        """
        Single configuration entry in a prj.conf file, like CONFIG_ABC=y
        """
        self.name = name
        self.loc = loc
        self.raw = assignment.strip()
        self.value_range = value_range

    @property
    def range(self):
        """Range of the name text, ie CONFIG_ABC"""
        return self.loc.range

    def __eq__(self, o: object) -> bool:
        if not isinstance(o, ConfEntry):
            return False
        return self.loc == o.loc

    @property
    def full_range(self):
        """Range of the entire assignment, ie CONFIG_ABC=y"""
        return Range(self.range.start, self.value_range.end)

    def is_string(self):
        return self.raw.startswith('"') and self.raw.endswith('"')

    def is_bool(self):
        return self.raw in ['y', 'n']

    def is_hex(self):
        return re.match(r'0x[a-fA-F\d]+', self.raw)

    def is_int(self):
        return re.match(r'\d+', self.raw)

    @property
    def str_value(self):
        """Value in format matching kconfig.Symbol.str_value"""
        if self.is_string():
            return self.raw[1:-1]  # strip out quotes
        return self.raw

    @property
    def value(self):
        """Value assigned in the entry, as seen by kconfig"""
        if self.is_string():
            return self.raw[1:-1]  # strip out quotes
        if self.is_bool():
            return self.raw
        if self.is_hex():
            return int(self.raw, 16)
        if self.is_int():
            return int(self.raw)

    @property
    def type(self):
        """Human readable entry type, derived from the assigned value."""
        if self.is_string():
            return kconfig.TYPE_TO_STR[kconfig.STRING]
        if self.is_hex():
            return kconfig.TYPE_TO_STR[kconfig.HEX]
        if self.is_int():
            return kconfig.TYPE_TO_STR[kconfig.INT]
        if self.is_bool():
            return kconfig.TYPE_TO_STR[kconfig.BOOL]

        return kconfig.TYPE_TO_STR[kconfig.UNKNOWN]

    @property
    def line_range(self):
        """Entire line range."""
        return Range(Position(self.range.start.line, 0), Position(self.range.start.line + 1, 0))

    def remove(self, title='Remove entry') -> CodeAction:
        """Create a code action that will remove this entry"""
        action = CodeAction(title)
        action.edit.add(self.loc.uri, TextEdit.remove(self.line_range))
        return action


class ConfFile:
    def __init__(self, uri: Uri):
        """
        Single .conf file.

        Each Kconfig context may contain a list of conf files that must be parsed.
        The .conf file does not parse or understand the entry names and their interpreted value.
        """
        self.uri = uri
        self.diags: List[Diagnostic] = []

    @staticmethod
    def entries(doc: Optional[TextDocument], prefix) -> List[ConfEntry]:
        """The ConfEntries in the given text document"""
        if doc is None:
            return []

        entries = []
        for linenr, line in enumerate(doc.lines):
            match = re.match(r'^\s*(' + prefix + r'(\w+))\s*\=("[^"]+"|\w+)', line)
            if match:
                range = Range(Position(linenr, match.start(1)), Position(linenr, match.end(1)))
                value_range = Range(
                    Position(linenr, match.start(3)), Position(linenr, match.end(3))
                )
                entries.append(ConfEntry(match[2], Location(doc.uri, range), match[3], value_range))
        return entries

    def __repr__(self):
        return str(self.uri)


class ConfigChanges(NamedTuple):
    """
    Object containing suggested changes to a configuration
    """

    added: List[kconfig.Symbol]
    deleted: List[ConfEntry]


class KconfigErrorCode(enum.IntEnum):
    """Set of Kconfig specific error codes reported in response to failing requests"""

    UNKNOWN_NODE = 1  # The specified node is unknown.
    # The kconfig data has been changed, and the menu tree is out of sync.
    DESYNC = 2
    PARSING_FAILED = 3  # Kconfig tree couldn't be parsed.


class Kconfig(kconfig.Kconfig):
    def __init__(self, documentStore: DocumentStore, filename='Kconfig'):
        """
        Wrapper of kconfiglib's Kconfig object.

        Overrides the diagnostics mechanism to keep track of them in a dict instead
        of writing them to stdout.

        Overrides the _open function to inject live editor data from the documentStore.
        """
        self.diags: Dict[str, List[Diagnostic]] = {}
        self.warn_assign_undef = True
        self.warn_assign_override = True
        self.warn_assign_redun = True
        self.filename = filename
        self.valid = False
        self.documentStore = documentStore
        self.files: Dict[str, set[str]]
        self.tree_stack: List[str]

    def parse(self):
        """
        Parse the kconfig tree.

        This is split out from the constructor to avoid nixing the whole object on parsing errors.
        """
        self.valid = False
        try:
            self._init(self.filename, True, False, 'utf-8')
        except Exception as e:
            print(str(e))
            if hasattr(self, '_filestack'):
                print(f'Encountered a parsing error, closing {len(self._filestack)} files')
                # Close all files, so we don't end up locking them forever:
                while len(self._filestack) > 0:
                    self._leave_file()
            if hasattr(self, '_readline') and self._readline:
                self._readline.__self__.close()
            raise
        if self.unique_defined_syms:
            self.valid = True

    def loc(self):
        if self.filename and self.linenr != None:
            return Location(
                Uri.file(os.path.join(self.srctree, self.filename)),
                Range(Position(self.linenr - 1, 0), Position(self.linenr - 1, 99999)),
            )

    # Overriding _open to work on virtual file storage when required:
    def _open(self, filename: Union[str, Uri], mode):
        # Read from document store, but don't create an entry if it doesn't exist:
        uri = filename if isinstance(filename, Uri) else Uri.file(filename)
        doc = self.documentStore.get(uri, create=False)
        if doc:
            doc.open(mode)
            return doc
        if uri.scheme != 'file':
            raise kconfig.KconfigError(f'Unknown context {uri}')
        if os.path.isdir(uri.path):
            raise kconfig.KconfigError(
                f'Attempting to open directory {uri.path} as file @{self.filename}:{self.linenr}'
            )
        return super()._open(uri.path, mode)

    def _warn(self, msg: str, filename=None, linenr=None):
        super()._warn(msg, filename, linenr)
        if not self.warn:
            return

        if not filename:
            filename = ''
        if not linenr:
            linenr = 1

        if not filename in self.diags:
            self.diags[filename] = []

        # Strip out potentially very long definition references.
        # They're redundant, since the user can ctrl+click on the symbol to interactively find them.
        msg = re.sub(r'\s*\(defined at.*?\)\s*', ' ', msg)

        if "set more than once. Old value" in msg:
            # self.duplicate_assign_cache
            msg = msg.replace(
                'set more than once',
                "set more than once in the active context. Check files under Details View > Config files > Kconfig.",
            )
            self.diags[filename].append(
                Diagnostic(msg, Position(int(linenr - 1), 0).range, KCONFIG_HINT_LVL)
            )
        else:
            self.diags[filename].append(
                Diagnostic(msg, Position(int(linenr - 1), 0).range, KCONFIG_WARN_LVL)
            )

    def _init(self, filename, warn, warn_to_stderr, encoding):
        # initialise file tree and stack
        filename = normpath(filename)
        self.files = {filename: set()}
        self.tree_stack = [filename]

        super()._init(filename, warn, warn_to_stderr, encoding)

    def _enter_file(self, filename):
        # build kconfig import file tree
        filename = normpath(filename)
        if os.path.isfile(filename):
            # check if file exists in lookup table
            if not self.files.get(filename):
                self.files[filename] = set()

            # append path to child paths of parent file
            parent_file = self.tree_stack[-1]
            self.files[parent_file].add(filename)

            # store file in tree stack
            self.tree_stack.append(filename)

        super()._enter_file(filename)

    def _leave_file(self):
        super()._leave_file()
        # restore parent for file tree traversial
        self.tree_stack.pop()


class KconfigContext:
    def __init__(
        self,
        uri: Uri,
        ctx_id,
        root,
        documentStore: DocumentStore,
        conf_files: List[ConfFile] = [],
        board_conf_files: List[ConfFile] = [],
        env={},
        build_context_name=None,
    ):
        """A single instance of a kconfig compilation.
        Represents one configuration of one application, equalling a single
        build in Zephyr.
        """
        self.uri = uri
        self.env = env
        self.ctx_id = ctx_id
        self.build_context_name = build_context_name
        self.documentStore = documentStore
        self.conf_files = conf_files
        self.board_conf_files = board_conf_files
        self.version = 0
        self._root = root
        self._kconfig: Optional[Kconfig] = None
        self.menu = None
        self.cmd_diags: List[Diagnostic] = []
        self.last_access = 0
        self.default: Dict[str, str] = {}
        self.kconfig_diags: Dict[str, List[Diagnostic]] = {}
        self.prefix = cast(Optional[str], env.get('CONFIG_')) or 'CONFIG_'
        self.original_values: Dict[str, str] = {}

        # Create a virtual minimal config file:
        doc = TextDocument(Uri('ctx', path=self.uri.path))
        self.documentStore.open(doc)
        self.min_conf = ConfFile(doc.uri)

    def initialize_env(self):
        """
        Apply the context environment for the entire process.

        kconfig will access os.environ without a wrapper to
        resolve variables like ZEPHYR_BASE.
        """
        old_zephyr_base = os.getenv('ZEPHYR_BASE')
        for key, value in self.env.items():
            os.environ[key] = value

        # functions_path should be the first entry, to ensure that the
        # kconfigfunctions module is loaded from this zephyr base:
        functions_path = os.path.join(self.env['ZEPHYR_BASE'], 'scripts', 'kconfig')
        if functions_path in sys.path:
            sys.path.remove(functions_path)
        sys.path.insert(0, functions_path)

        if old_zephyr_base:
            # Normalize path for the startswith check below:
            old_zephyr_base = os.path.normpath(old_zephyr_base)

            # We have to reload the Zephyr python modules to force
            # the edt pickle to be reloaded from the current build, as it may have changed:
            print('Reloading Zephyr python modules...')
            modules = list(sys.modules.values())

            for mod in modules:
                if (
                    hasattr(mod, '__file__')
                    and mod.__file__
                    # look in the previous location:
                    and mod.__file__.startswith(old_zephyr_base)
                ):
                    try:
                        print(f'Reloading {os.path.relpath(mod.__file__, old_zephyr_base)}')
                        # If ZEPHYR_BASE has moved, importlib will reload from the new location
                        importlib.reload(mod)
                    except Exception as e:
                        # kconfigfunctions aren't mandatory, so we'll just swallow the import failure
                        print(f'Kconfig function parsing failed: {e}')

    def doc(self, uri: Uri) -> Optional[TextDocument]:
        return self.documentStore.get(uri)

    def parse(self):
        """
        Parse the full kconfig tree.
        Will set up the environment and invoke kconfig to parse the entire kconfig
        file tree. This is only necessary to do once - or if any files in the Kconfig
        file tree changes.

        Throws kconfig errors if the tree can't be parsed.
        """
        self.menu = None

        for list in self.kconfig_diags.values():
            list.clear()

        self.initialize_env()
        self.default = {}

        self._kconfig = Kconfig(self.documentStore, self._root)

        try:
            self._kconfig.parse()

            # Keep a copy of the default values in memory for diff operations:

            # Disable all warnings during default value evaluation to avoid presenting them
            # to the user as a real problem with the build, as that may have different
            # settings that don't get the same warnings:
            self._kconfig.disable_warnings()

            if self._kconfig.valid:
                for sym in cast(List[kconfig.Symbol], self._kconfig.unique_defined_syms):
                    self.default[cast(str, sym.name)] = cast(str, sym.str_value)
        except kconfig.KconfigError as e:
            loc = self._kconfig.loc()

            # Strip out the GCC-style location indicator that is placed on the start of the
            # error message for some messages:
            match = re.match(r'(^[\w\/\\-]+:\d+:\s*)?(error:)?\s*(.*)', str(e))
            if match:
                msg = match[3]
            else:
                msg = str(e)

            if loc:
                self.kconfig_diag(loc.uri, Diagnostic.err(msg, loc.range))
            else:
                self.cmd_diags.append(
                    Diagnostic.err(msg, Range(Position.start(), Position.start()))
                )
        except Exception as e:
            self.cmd_diags.append(
                Diagnostic.err(
                    'Kconfig failed: ' + str(e),
                    Range(Position.start(), Position.start()),
                )
            )
        finally:
            self._kconfig.enable_warnings()
        self.version += 1

    def get_min_config(self) -> Optional[List[kconfig.Symbol]]:
        """
        Get the minimal configuration that will reproduce the current state.

        Copies Kconfig._min_config_contents, but adds extra consideration for
        int/hex values, which will be assigned a deterministic default value if
        no user value or default exists.
        """
        if self._kconfig is None or not self._kconfig.valid:
            return None

        changed = []

        for sym in self._kconfig.unique_defined_syms:
            if not sym.choice and sym.visibility <= kconfig.expr_value(sym.rev_dep):
                continue

            actual = sym.str_value
            default = sym._str_default()
            if actual == default:
                continue

            # If an int or a hex value has no default, they'll be assigned the value
            # that is closest to 0 inside the active range. If there's no active range,
            # it'll just be 0
            if sym.orig_type in kconfig._INT_HEX:
                base = kconfig._TYPE_TO_BASE[sym.orig_type]
                val = int(default, base) if default else 0
                for default, cond in sym.defaults:
                    if kconfig.expr_value(cond):
                        val = int(default.str_value, base)
                        break

                for low_expr, high_expr, cond in sym.ranges:
                    if kconfig.expr_value(cond):
                        try:
                            low = int(low_expr.str_value, base)
                        except ValueError:
                            low = 0

                        try:
                            high = int(high_expr.str_value, base)
                        except ValueError:
                            high = 0

                        val = max(val, low)
                        val = min(val, high)
                        break

                if int(actual, base) == val:
                    continue

            if (
                sym.choice
                and not sym.choice.is_optional
                and sym.choice._selection_from_defaults() is sym
                and sym.orig_type is kconfig.BOOL
                and sym.tri_value == 2
            ):
                continue

            changed.append(sym)

        return changed

    def get_changes(self):
        """
        Get the set of changes that has been performed on the configuration.

        The result is based on the minimal configuration, which means that the
        suggested changes will include removal of entries that cannot take effect
        due to missing dependencies.

        Will not remove entries that are the same as their default, as this is usually
        done deliberately in samples to force all boards to have the same base
        configuration as the main target board.
        """
        minimal = self.get_min_config()
        current = self.all_entries()
        changes = ConfigChanges([], [])

        if minimal is None:
            return changes

        sym: Optional[kconfig.Symbol] = None
        for sym in minimal:
            val = sym.str_value
            for curr in current:
                if curr.name == sym.name and curr.str_value == val:
                    break
            else:
                changes.added.append(sym)

        for curr in current:
            for sym in minimal:
                if sym.name == curr.name:
                    break
            else:
                # Check whether the entry is just redundant, which shouldn't
                # prompt a deletion:
                sym = self.symbol(curr.name)
                if sym:
                    if not sym.visibility or sym.str_value == curr.str_value:
                        # The symbol couldn't be assigned to, or is just the same as its
                        # default value. This just means that the prj.conf assignment
                        # is useless. The linting step will produce a hint for deleting
                        # it, so no need to delete it properly
                        continue
                changes.deleted.append(curr)

        return changes

    def get_edits(self, file: ConfFile) -> List[TextEdit]:
        """
        Get the list of text edits that should be applied to the given file for it to
        match the current configuration state.
        """
        doc = self.doc(file.uri)
        if not doc:
            return []

        changes = self.get_changes()
        entries = ConfFile.entries(doc, self.prefix)

        last_line = Position(len(doc.lines), 0)
        if not last_line or (len(entries) and entries[-1].range.end.line < last_line.line):
            last_line = Position(entries[-1].range.end.line + 1, 0)

        edits = []
        additions = []
        for sym in changes.added:
            existing = next((entry for entry in entries if entry.name == sym.name), None)

            insert = conf_string(sym, self.prefix)
            if existing:
                edits.append(TextEdit(existing.full_range, insert))
            else:
                additions.append(insert)

        if additions:
            separator = "" if doc.last_line_is_blank() else "\n"
            edits.append(TextEdit(Range(last_line, last_line), separator + "\n".join(additions)))

        for change in changes.deleted:
            # Only remove entries that appear in this file:
            existing = next((e for e in entries if e.name == change.name), None)
            if existing:
                edits.append(TextEdit(existing.line_range, ''))

        return edits

    def kconfig_diag(self, uri: Uri, diag: Diagnostic):
        if not str(uri) in self.kconfig_diags:
            self.kconfig_diags[str(uri)] = []
        self.kconfig_diags[str(uri)].append(diag)

    @property
    def valid(self):
        return self._kconfig is not None and self._kconfig.valid

    def failed_compilation(self):
        return self._kconfig is not None and not self._kconfig.valid

    @property
    def output_file(self) -> Optional[str]:
        """Path to output file. Normally <build>/zephyr/.config"""
        return self.env.get('KCONFIG_CONFIG')

    @property
    def output_header(self) -> str:
        """Absolute path to autogenerated header file"""
        return os.path.join(self.uri.path, 'zephyr', 'include', 'generated', 'autoconf.h')

    def invalidate(self):
        self._kconfig = None

    def in_kconfig_tree(self, uri: Uri):
        """Check whether the given file is a known Kconfig file"""
        if self._kconfig:
            files = set(self._kconfig.kconfig_filenames)
            srctree = self.env.get('ZEPHYR_BASE')
            for file in files:
                if Uri.file(os.path.join(srctree, file)) == uri:
                    return True
        return False

    @property
    def all_conf_files(self) -> List[ConfFile]:
        """All configuration files going into this build. Includes the board conf file."""
        return [*self.board_conf_files, *self.conf_files]

    def has_file(self, uri: Uri):
        """Check whether the given URI represents a conf file this context uses."""
        return any([(file.uri == uri) for file in self.all_conf_files])

    def _node_id(self, node: kconfig.MenuNode):
        """Encode a unique ID string for the given menu node"""
        if not self._kconfig:
            return ''

        item = cast(Union[kconfig.Symbol, kconfig.Choice, int], node.item)
        if node == self._kconfig.top_node:
            parts = ['MAINMENU']
        elif item == kconfig.MENU:
            parts = ['MENU', str(self._kconfig.menus.index(node))]
        elif isinstance(item, kconfig.Symbol):
            parts = ['SYM', cast(str, item.name), str(item.nodes.index(node))]
        elif isinstance(item, kconfig.Choice):
            parts = [
                'CHOICE',
                str(self._kconfig.choices.index(item)),
                str(item.nodes.index(node)),
            ]
        elif item == kconfig.COMMENT:
            parts = ['COMMENT', str(self._kconfig.comments.index(node))]
        else:
            parts = ['UNKNOWN', cast(str, node.filename), str(node.linenr)]

        parts.insert(0, str(self.version))

        return ID_SEP.join(parts)

    def find_node(self, id):
        """Find a menu node based on a node ID"""
        [version, type, *parts] = id.split(ID_SEP)

        if int(version) != self.version:
            # Since we're building on the exact layout of the internals of the
            # kconfig tree, the node IDs depend on the fact that the tree is unchanged:
            return None

        if self._kconfig is None:
            return None

        if type == 'MENU':
            return self._kconfig.menus[int(parts[0])]

        if type == 'SYM':
            return self._kconfig.syms[parts[0]].nodes[int(parts[1])]

        if type == 'CHOICE':
            return self._kconfig.choices[int(parts[0])].nodes[int(parts[1])]

        if type == 'COMMENT':
            return self._kconfig.comments[int(parts[0])]

        if type == 'MAINMENU':
            return self._kconfig.top_node

    def get_menu(self, id=None):
        """Get the KconfigMenu for the menu node with the given ID"""
        if self._kconfig is None or not self._kconfig.valid:
            return

        if id:
            node = self.find_node(id)
        else:
            node = self._kconfig.top_node
            id = self._node_id(node)

        if not node:
            return
        return KconfigMenu(self, node, id)

    def set(self, name, val: Optional[str], id=None) -> bool:
        """Set a config value (without changing the conf files)"""
        sym = None
        if id:
            node = self.find_node(id)
            if node:
                sym = node.item
        else:
            sym = self.get(name)
        if not sym:
            raise RPCError(KconfigErrorCode.UNKNOWN_NODE, 'Unknown symbol {}'.format(name))

        if isinstance(sym, kconfig.Symbol) and name not in self.original_values:
            if sym.choice and sym.choice.selection:
                self.original_values[name] = sym.choice.selection.name
            else:
                self.original_values[name] = sym.str_value

        if val is None:
            sym.unset_value()
            return True

        return sym.set_value(val)

    def reset(self, name) -> bool:
        """Set a config value (without changing the conf files) and store the original values"""
        sym = self.get(name)

        if not sym:
            raise RPCError(KconfigErrorCode.UNKNOWN_NODE, 'Unknown symbol {}'.format(name))

        val = self.original_values.get(name)
        if val:
            if isinstance(sym, kconfig.Symbol) and sym.choice:
                original_sym = self.get(val)
                if isinstance(original_sym, kconfig.Symbol) and original_sym.set_value("y"):
                    self.original_values.pop(name)
                    return True
                return False
            if sym.set_value(val):
                self.original_values.pop(name)
                return True
        return False

    def get(self, name) -> Union[kconfig.Symbol, kconfig.Choice, None]:
        """
        Get a kconfig symbol or choice based on its name.
        The name should NOT include the CONFIG_ prefix.
        """
        if self._kconfig is None:
            return None

        return self._kconfig.syms.get(name) or next(
            (choice for choice in self._kconfig.choices if choice.name == name), None
        )

    def conf_file(self, uri: Uri) -> Optional[ConfFile]:
        """Get the config file with the given URI, if any."""
        return next((file for file in self.all_conf_files if file.uri == uri), None)

    def clear_conf_diags(self):
        """Clear all diagnostics in conf files"""
        if self._kconfig:
            self._kconfig.diags.clear()
        self.cmd_diags.clear()
        for conf in self.all_conf_files:
            conf.diags.clear()

    def symbols(self, filter: Optional[str] = None, only_visible=False) -> List[kconfig.Symbol]:
        """Get a list of symbols matching the given filter string. Can be used for search or auto completion."""
        if filter and filter.startswith(self.prefix):
            filter = filter[len(self.prefix) :]

        if not self._kconfig or not self._kconfig.valid:
            return []

        return [
            sym
            for sym in cast(List[kconfig.Symbol], self._kconfig.unique_defined_syms)
            # Literal values are also symbols, but can be filtered out by checking sym.nodes
            # which only exists if this is a proper config symbol:
            if hasattr(sym, 'nodes')
            and len(sym.nodes)
            and (not only_visible or get_prompt(sym))
            and (not filter or _filter_match(filter, cast(str, sym.name)))
        ]

    def symbol(self, name: str) -> Optional[kconfig.Symbol]:
        """
        Get symbol with the given name if the context is valid
        """
        if self._kconfig is None or not self._kconfig.valid:
            return None
        return self._kconfig.syms.get(name)

    def menu_item(self, name: str) -> Optional[MenuItem]:
        """
        Get a menu item from the given symbol.
        Will only return if the name is an exact name for a symbol
        that can be rendered as a menu item.
        """
        sym = self.symbol(name)
        if sym:
            return MenuItem.from_sym(self, sym)
        return None

    def get_proxy_options(self, sym: kconfig.Symbol):
        """
        Choices generally aren't referenced directly in the source
        code, as they don't have the value of the selection.
        Instead, they follow a special design pattern that circumvents
        this limitation:

        If a choice is meant to be a selection between integer values,
        the kconfig symbols are set up so that the choice itself is
        visible in menuconfig, and contains several boolean options.
        Below the choice, a separate, hidden item is created. This
        has a set of default values, each enabled by one of the options
        in the choice. In the C code, we use the value of this hidden
        symbol, which will be set to one of the default integer values,
        based on what the user entered in the choice.

        See for instance CONFIG_<module>_LOG_LEVEL:
        https://github.com/zephyrproject-rtos/zephyr/blob/main/subsys/logging/Kconfig.template.log_config
        Here, the $(module)_LOG_LEVEL symbol is hidden. Its value is
        controlled by the $(module)_LOG_LEVEL_CHOICE choice right above
        it, which has one option for each of its default values.

        This function gets the options that represent the different
        default values in the passed item (which should be the hidden
        item referenced in the source code).
        """
        options: List[kconfig.Symbol] = []
        if self._kconfig is None or not self._kconfig.valid:
            return []

        for _, condition in sym.orig_defaults:
            # Ensure all defaults are on the form "default X if Y":

            # Can't enable something with no condition, skip this:
            if condition == self._kconfig.y:
                continue

            # Only support single-symbol conditions:
            if not isinstance(condition, kconfig.Symbol):
                return []

            # Condition must be an option in a choice:
            if not condition.choice:
                return []

            # All options must belong to the same choice:
            if len(options) > 0 and condition.choice != options[0].choice:
                return []

            options.append(condition)

        return options

    def symbols_in_doc(
        self, uri: Uri, range: Optional[Range] = None
    ) -> List[Tuple[kconfig.Symbol, Range]]:
        """
        Get all symbols in the given document and range.
        Only works for CONFIG_XYZ style symbols.
        """
        doc = self.documentStore.get(uri, False)
        if doc is None:
            return []

        results = []

        for n, line in enumerate(doc.get(range.lines() if range else None).splitlines()):
            if range:
                n += range.start.line

            for match in re.finditer(self.prefix + r'(\w+)', line):
                sym_range = Range(*[Position(n, col) for col in match.span()])
                if range and not range.overlaps(sym_range):
                    continue

                sym = self.symbol(match.group(1))
                if sym:
                    results.append((sym, sym_range))

        return results

    def setval_action(self, title: str, sym: kconfig.Symbol, value: str):
        """Create a setVal Code action"""
        action = CodeAction(title)
        action.command = Command(action.title, 'kconfig.set', self.uri, sym.name, value)
        return action

    def get_setval_actions(self, loc: Location) -> List[CodeAction]:
        """
        Get code actions that can be used to change symbol values for all
        symbols in the given location.
        """
        actions = []
        symbols = self.symbols_in_doc(loc.uri, loc.range)
        for sym, range in symbols:
            # Only visible symbols can be revealed in menuconfig:
            prompt = get_prompt(sym)
            if prompt:
                action = CodeAction(f'Open {self.prefix}{sym.name} in the Kconfig UI')
                action.command = Command(
                    action.title,
                    'kconfig.showGui',
                    sym.name,
                )
                actions.append(action)

            # Toggles:
            if sym.type in kconfig._BOOL_TRISTATE:
                # Will always be either enable or disable, if it can be set.
                # Cycle through sym.assignable to ensure we only show options
                # that can be set legally. If a variable can't be set because
                # of dependencies, this will make sure it doesn't get added
                # as a legal action.
                curr = sym.tri_value
                for assignment in sym.assignable:
                    toggle = 'Disable' if curr else 'Enable'
                    if curr != assignment:
                        actions.append(
                            self.setval_action(
                                f'{toggle} {self.prefix}{sym.name} in {self.build_context_name}',
                                sym,
                                'n' if curr else 'y',
                            )
                        )
                continue

            # Multiple options. Proxy options do not have prompts.
            if not isinstance(sym, kconfig.Choice) and prompt is None:
                options = [
                    option
                    for option in self.get_proxy_options(sym)
                    # No need to change to the current value:
                    if option != option.choice.selection
                ]

                # Skip the choice actions if there are an unreasonable amount of choices:
                if len(options) < 8:
                    for option in options:
                        name = get_prompt(option, True)
                        if name:
                            # Wrap the prompt in quotes:
                            name = f'"{name}"'
                        else:  # fallback
                            name = self.prefix + option.name

                        actions.append(
                            self.setval_action(
                                f'Change {self.prefix}{sym.name} to {name}', option, 'y'
                            )
                        )
                else:
                    # Add the proxied choice to the list of symbols, so we can push an "Open in menu" action for it:
                    symbols.append((options[0].choice, range))

        return actions

    def fuzzy_symbols(self, pattern: str, only_visible=True) -> List[kconfig.Symbol]:
        """Get a list of symbols matching the given filter string. Can be used for search or auto completion."""
        search_prompt = True
        search_name = True

        if not self._kconfig or not self._kconfig.valid:
            return []

        upper = pattern.upper()

        # Infer whether we should search in the name, prompt or both based on formatting:
        if upper.startswith(self.prefix):
            pattern = pattern[len(self.prefix) :]
            search_prompt = False

        def get_filter_string(sym: kconfig.Symbol) -> str:
            parts = []
            if search_prompt:
                prompt = get_prompt(sym, ignore_expr=True)
                if prompt:
                    parts.append(prompt)
            if search_name:
                parts.append(sym.name)
            return ','.join(parts)

        symbols = self.symbols(only_visible=only_visible)
        start = datetime.now()
        result = fuzzy_sort(pattern, symbols, key=get_filter_string)
        end = datetime.now()
        print(f'Fuzzy matched {len(symbols)} symbols in {(end - start).microseconds // 1000} ms')
        return result

    def symbol_search(self, pattern: str, only_visible=True) -> List[MenuItem]:
        """
        Search for a symbol with a specific name. Returns a list of menu nodes representing the
        symbols.

        Each symbol will appear only once, represented by its first accessible menu node.
        """
        results: Dict[str, MenuItem] = {}
        for sym in self.fuzzy_symbols(pattern, only_visible=only_visible):
            item = MenuItem.from_sym(self, sym)

            # Nodes with no prompts will not show up in the search
            if item:
                if item.id not in results.keys():
                    results[item.id] = item
                parent_node = self.find_node(item.path[-1])
                if parent_node:
                    parent_item = MenuItem(self, parent_node)
                    if parent_item and parent_item.id not in results.keys():
                        results[parent_item.id] = parent_item

        return list(results.values())

    def all_entries(self) -> List[ConfEntry]:
        entries = []
        for file in self.all_conf_files:
            entries.extend(ConfFile.entries(self.doc(file.uri), self.prefix))

        # Keep only unique entries by name, preserving the last occurrence
        unique_entries = {}
        for entry in entries:
            unique_entries[entry.name] = entry

        return list(unique_entries.values())

    # Link checks for config file entries:

    def check_undefined(self, file: ConfFile, entry: ConfEntry, sym: Optional[kconfig.Symbol]):
        if sym is None or sym.type == kconfig.UNKNOWN:
            file.diags.append(
                Diagnostic.err(f'Unknown symbol {self.prefix}{entry.name}', entry.full_range)
            )
            return True

    def check_type(self, file: ConfFile, entry: ConfEntry, sym: kconfig.Symbol):
        """Check that the configured value has the right type."""
        if kconfig.TYPE_TO_STR[sym.type] != entry.type:
            diag = Diagnostic.err(
                f'Invalid type. Expected {kconfig.TYPE_TO_STR[sym.type]}',
                entry.full_range,
            )

            # Add action to convert between hex and int:
            if sym.type in [kconfig.HEX, kconfig.INT] and (entry.is_hex() or entry.is_int()):
                action = CodeAction('Convert value to ' + str(kconfig.TYPE_TO_STR[sym.type]))
                if sym.type == kconfig.HEX:
                    action.edit.add(entry.loc.uri, TextEdit(entry.value_range, hex(entry.value)))
                else:
                    action.edit.add(entry.loc.uri, TextEdit(entry.value_range, str(entry.value)))
                diag.add_action(action)

            file.diags.append(diag)
            return True

    def check_assignment(self, file: ConfFile, entry: ConfEntry, sym: kconfig.Symbol):
        """Check that the assigned value actually was propagated."""
        user_value = sym.user_value
        if user_value is not None and sym.type in [kconfig.BOOL, kconfig.TRISTATE]:
            user_value = kconfig.TRI_TO_STR[user_value]

        actions = []
        if user_value == sym.str_value:
            if user_value == 'y':
                return
            msg = f'{self.prefix}{sym.name} was already disabled.'
            severity = Diagnostic.HINT
        elif len(sym.str_value):
            msg = f'{self.prefix}{sym.name} was assigned the value {entry.raw}, but got the value {sym.str_value}.'
            severity = Diagnostic.WARNING
        else:
            msg = f'{self.prefix}{sym.name} couldn\'t be set.'
            severity = Diagnostic.WARNING

        deps = _missing_deps(sym)
        if deps:
            msg += ' Missing dependencies:\n'
            msg += ' && '.join([kconfig.expr_str(dep) for dep in deps])
            edits: List[Tuple[str, TextEdit]] = []
            entries = ConfFile.entries(self.doc(file.uri), self.prefix)

            for dep in deps:
                if isinstance(dep, kconfig.Symbol) and dep.type == kconfig.BOOL:
                    dep_entry = next(
                        (entry for entry in entries if entry.name == dep.name),
                        None,
                    )
                    if dep_entry:
                        edits.append(
                            (
                                cast(str, dep.name),
                                TextEdit(dep_entry.value_range, 'y'),
                            )
                        )
                    else:
                        edits.append(
                            (
                                cast(str, dep.name),
                                TextEdit(
                                    Range(entry.line_range.start, entry.line_range.start),
                                    f'{self.prefix}{dep.name}=y\n',
                                ),
                            )
                        )

            if len(edits) == 1:
                edit = edits[0]
                action = CodeAction(f'Enable {self.prefix}{edit[0]} to resolve dependency')
                action.edit.add(file.uri, edit[1])
                actions.append(action)
            elif len(edits) > 1:
                action = CodeAction(f'Enable {len(edits)} entries to resolve dependencies')

                # Dependencies are registered with a "nearest first" approach in kconfig.
                # As the nearest dependency is likely lowest in the menu hierarchy, we'll
                # reverse the list of edits, so the highest dependency is inserted first:
                edits.reverse()

                for edit in edits:
                    action.edit.add(file.uri, edit[1])
                actions.append(action)

            actions.append(entry.remove())

            diag = Diagnostic(msg, entry.range, severity)
            if severity == Diagnostic.HINT:
                diag.mark_unnecessary()
            for action in actions:
                diag.add_action(action)

            file.diags.append(diag)
            return True

    def check_visibility(self, file: ConfFile, entry: ConfEntry, sym: kconfig.Symbol):
        """Check whether the configuration entry actually can be set in config files."""
        if not any(node.prompt for node in sym.nodes):
            diag = Diagnostic.warn(
                f'Symbol {self.prefix}{entry.name} cannot be set (has no prompt)',
                entry.full_range,
            )
            diag.add_action(entry.remove())
            file.diags.append(diag)
            return True

    def check_defaults(self, file: ConfFile, entry: ConfEntry, sym: kconfig.Symbol):
        """Check whether an entry's value matches the default value, and mark it as redundant"""
        if sym._str_default() == sym.user_value:
            diag = Diagnostic.hint(f'Value is {entry.raw} by default', entry.full_range)
            diag.mark_unnecessary()
            diag.add_action(entry.remove('Remove redundant entry'))
            file.diags.append(diag)
            return True

    def lint(self):
        """
        Run a set of checks on the contents of the conf files.

        Adds diagnostics to the failing entries to help developers fix errors
        that will come up when compiling. Reimplements some checks from
        generate_config.py that show up during the build, as these aren't
        part of kconfig.
        """
        if self._kconfig is None or not self._kconfig.valid:
            return

        for file in self.conf_files:
            print(f'lint: {file.uri.path}')
            entries = ConfFile.entries(self.doc(file.uri), self.prefix)
            for entry in entries:
                sym = cast(kconfig.Symbol, self._kconfig.syms.get(entry.name))
                if self.check_undefined(file, entry, sym):
                    continue
                if self.check_type(file, entry, sym):
                    continue
                if self.check_assignment(file, entry, sym):
                    continue
                if self.check_visibility(file, entry, sym):
                    continue
                if self.check_defaults(file, entry, sym):
                    continue

    def load_config(self):
        """
        Load configuration files and update the diagnostics.
        Will be a no-op if the kconfig tree isn't valid or none of the files
        have changed.
        """
        if self._kconfig is None or not self._kconfig.valid:
            return

        try:
            self.clear_conf_diags()

            self.original_values = {}

            print('Load conf files...')
            # Load from the conf files:
            for file in self.board_conf_files:
                self._kconfig.load_config(file.uri.path, replace=True)

            for file in self.conf_files:
                self._kconfig.load_config(file.uri.path, replace=False)

            self.lint()

            for filename, diags in self._kconfig.diags.items():
                if filename == '':
                    self.cmd_diags.extend(diags)
                else:
                    uri = Uri.file(filename)
                    conf = self.conf_file(uri)
                    if conf:
                        conf.diags.extend(diags)
                    else:
                        self.cmd_diags.extend(diags)
        except AttributeError as e:
            self.cmd_diags.append(
                Diagnostic.err(
                    'Kconfig tree parse failed: Invalid attribute ' + str(e),
                    Range(Position.start(), Position.start()),
                )
            )
        except Exception as e:
            self.cmd_diags.append(
                Diagnostic.err(
                    'Kconfig tree parse failed: ' + str(e),
                    Range(Position.start(), Position.start()),
                )
            )

    def symbol_at(self, uri: Uri, pos):
        """Get the symbol referenced at a given position in a conf file."""
        doc = self.documentStore.get(uri)
        if not doc:
            return

        word = doc.word_at(pos)
        if word:
            if re.match(r'Kconfig.*', uri.basename):
                return self.get(word)

            if word.startswith(self.prefix):
                return self.get(word[len(self.prefix) :])

    def save(self):
        """
        Save the live state to the build folder.

        Saves both the .config file and the header file, to ensure
        that the C intellisense gets updated immediately.
        """
        if self._kconfig is not None:
            # Order matters, as the build system will rewrite the header if
            # .config is newer:
            result = self._kconfig.write_config(self.output_file)
            try:
                os.makedirs(os.path.dirname(self.output_header), exist_ok=True)
                self._kconfig.write_autoconf(self.output_header)
            except:
                # Ignore the result of the header write, it can be
                # recovered from .config by the build system if it fails.
                pass
            return result

    def get_imports(self, path: str) -> List[KconfigFileTreeItem]:
        """
        Returns all import paths of the Kconfig file with the given path
        """
        if not self._kconfig or len(self._kconfig.files) == 0:
            return []

        if path:
            path = normpath(path)
            children = self._kconfig.files.get(path)
            if children:
                return [
                    KconfigFileTreeItem(child, len(self._kconfig.files.get(child, [])) > 0)
                    for child in children
                ]

        root = list(self._kconfig.files.keys())[0]
        return [KconfigFileTreeItem(root, len(self._kconfig.files[root]) > 0)]

    def __repr__(self):
        return str(self.uri)
