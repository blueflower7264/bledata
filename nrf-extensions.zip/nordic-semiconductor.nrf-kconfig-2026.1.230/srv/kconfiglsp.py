# Copyright (c) 2021 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: LicenseRef-Nordic-1-Clause

from __future__ import annotations
from typing import Optional, List, Dict, cast, TypeVar
from kconfigctx import ConfEntry, ConfFile, DiffMenuItem, KconfigContext
import kconfiglib as kconfig
import sys
import os
import re
import argparse
from rpc import handler
from lsp import (
    CompletionItemKind,
    Diagnostic,
    DocumentSymbol,
    FileChangeKind,
    InsertTextFormat,
    LSPServer,
    MarkupContent,
    Position,
    Location,
    Snippet,
    SymbolInformation,
    SymbolKind,
    Uri,
    Range,
)
from symbols import conf_string, loc, get_prompt


#################################################################################################################################
# Kconfig LSP Server
#################################################################################################################################

# Environment variables passed to menuconfig:
# - ZEPHYR_BASE
# - ZEPHYR_TOOLCHAIN_VARIANT -> default to "zephyr"
# - PYTHON_EXECUTABLE
# - srctree=${ZEPHYR_BASE}
# - KERNELVERSION from ./VERSION, as a hex number, see version.cmake
# - KCONFIG_CONFIG=${PROJECT_BINARY_DIR}/.config
# - ARCH
# - ARCH_DIR
# - BOARD_DIR
# - SHIELD_AS_LIST
# - KCONFIG_BINARY_DIR=${CMAKE_BINARY_DIR}/Kconfig
# - TOOLCHAIN_KCONFIG_DIR -> default to ${TOOLCHAIN_ROOT}/cmake/toolchain/${ZEPHYR_TOOLCHAIN_VARIANT}
# - EDT_PICKLE
# - ZEPHYR_{modules}_MODULE_DIR -> get from west?
# - EXTRA_DTC_FLAGS -> Appear to be unused
# - DTS_POST_CPP -> ${PROJECT_BINARY_DIR}/${BOARD}.dts.pre.tmp
# - DTS_ROOT_BINDINGS -> ${DTS_ROOTs}/dts/bindings

KCONFIG_WARN_LVL = Diagnostic.WARNING
VERSION = '1.0'


# https://github.com/python/typing/issues/645
T = TypeVar('T')


def not_optional(arg: Optional[T]) -> T:
    assert arg is not None
    return arg


def _language(uri: Uri) -> Optional[str]:
    """Get the language ID of the file with a given URI"""
    basename = uri.basename.lower()
    if (
        basename.endswith('.conf')
        or basename.endswith('_defconfig')
        or basename.endswith('.config.sysbuild')
    ):
        return 'conf'
    if re.match(r'^kconfig(?:\..+)?', basename):
        return 'kconfig'
    if any(ext for ext in ['.c', '.cpp', '.h', '.hpp', '.cxx', '.hxx'] if basename.endswith(ext)):
        return 'c'
    return None


class KconfigServer(LSPServer):
    def __init__(self, istream=None, ostream=None):
        """
        The Kconfig LSP Server.

        The LSP Server should be instantiated once for each IDE instance, and is capable of
        handling multiple different Kconfig contexts using create_ctx().

        To run a kconfig server, instantiate it and call loop():

        KconfigServer().loop()

        This will keep running until KconfigServer.running is false.
        """
        super().__init__('zephyr-kconfig', VERSION, istream, ostream)
        self.main_uri = None
        self.main_ctxId = None
        self.access_count = 0
        self.ctx: Dict[str, KconfigContext] = {}
        print('Python version: ' + sys.version)

    def publish_diags(self, uri, diags: List[Diagnostic]):
        """Send a diagnostics publication notification"""
        self.notify(
            'textDocument/publishDiagnostics',
            {
                'uri': uri,
                'diagnostics': diags,
            },
        )

    def reset_ctx_diag(self, ctxId):
        if ctxId in self.ctx:
            ctx = self.ctx[ctxId]
            for conf in ctx.all_conf_files:
                self.publish_diags(conf.uri, [])

            for uri in ctx.kconfig_diags.keys():
                self.publish_diags(uri, [])

    def refresh_ctx(self, ctx: KconfigContext):
        """Reparse the given Kconfig context, and publish diagsnostics"""
        if not ctx.valid:
            if ctx.failed_compilation():
                print('Waiting for change to Kconfig tree')
                return
            else:
                print('Parsing...')
                ctx.parse()

        if ctx.valid:
            print('Load config...')
            ctx.load_config()

            for file in ctx.all_conf_files:
                print(f'Ctx File: {file.uri.path}, diags {len(file.diags)}')

            print(
                'Done. {} diags, {} warnings'.format(
                    sum([len(file.diags) for file in ctx.all_conf_files]),
                    len(cast(kconfig.Kconfig, ctx._kconfig).warnings),
                )
            )

        add_cmd_diag = len(ctx.all_conf_files) > 0
        for conf in ctx.all_conf_files:
            # Add command line diags to the last prj.conf file, as there's
            # no way to present diagnostics without a URI:
            if add_cmd_diag and conf == ctx.all_conf_files[-1]:
                self.publish_diags(conf.uri, conf.diags + ctx.cmd_diags)
            else:
                self.publish_diags(conf.uri, conf.diags)

        for uri, diags in ctx.kconfig_diags.items():
            self.publish_diags(uri, diags)

        self.notify_status(ctx)
        self.notify_changed_values(ctx)

    def notify_status(self, ctx: Optional[KconfigContext]):
        if not ctx:
            self.notify('kconfig/status', {'ctx': None, 'success': False})
        else:
            print('Status: ' + str(ctx.valid))
            self.notify(
                'kconfig/status',
                {
                    'ctx': ctx.uri,
                    'success': ctx.valid,
                    'app_dir': ctx.env.get('APPLICATION_SOURCE_DIR'),
                    'build_dir': ctx.uri.path,
                    'build_context_name': ctx.build_context_name,
                    'ctxId': ctx.ctx_id,
                },
            )

    def notify_changed_values(self, ctx: KconfigContext):
        files = []
        for conf_file in ctx.all_conf_files:
            entries = []
            for e in ConfFile.entries(self.documentStore.get(conf_file.uri), ctx.prefix):
                sym = ctx.get(e.name)
                if isinstance(sym, kconfig.Symbol) and sym.str_value != e.str_value:
                    if sym.orig_type == kconfig.STRING:
                        value = f'"{sym.str_value}"'
                    else:
                        value = sym.str_value
                    entries.append(
                        {
                            'value': value,
                            'line': e.range.start.line,
                        }
                    )
            files.append({'path': conf_file.uri, 'entries': entries})
        self.notify('kconfig/changedValues', {'ctx': ctx.uri, 'files': files})

    def create_ctx(self, uri: Uri, root, conf_files, board_files, env, ctxId, ctx_name):
        """
        Create a Kconfig Context with the given parameters.

        A context represents a single build directory.
        """
        doc_store = self.documentStore
        print(f'Creating context {uri}')
        ctx = KconfigContext(uri, ctxId, root, doc_store, conf_files, board_files, env, ctx_name)

        self.ctx[ctxId] = ctx
        return ctx

    @property
    def active_ctx(self) -> Optional[KconfigContext]:
        """
        Get the context that is the most likely owner of the given URI.

        Keeps track of the currently referenced context, and will prefer
        this if it owns the given URI.
        """
        return self.ctx.get(str(self.main_ctxId))

    def get_sym(self, params):
        """
        Get the symbol located at the given Location.
        Interprets location from a common location parameter format:
        - textDocument.uri -> URI
        - position -> Position
        """
        uri = Uri.parse(params['textDocument']['uri'])
        ctx = self.active_ctx
        if not ctx:
            print('No context for {}'.format(uri.path))
            return

        if not ctx.valid:
            self.refresh_ctx(ctx)

        return ctx.symbol_at(uri, Position.create(params['position']))

    @handler('initialized')
    def handle_initialized(self, params):
        self.watch_files('**/Kconfig*')
        self.watch_files('**/edt.pickle')
        self.watch_files('**/kconfigfunctions.py')

    @handler('kconfig/addBuild')
    def handle_add_build(self, params):
        uri = Uri.parse(params['uri'])
        ctxId = params['ctxId']
        build_context_name = params.get('build_context_name')

        confFiles = [ConfFile(Uri.file(f)) for f in params['conf']]
        board_conf_files = [ConfFile(Uri.file(f)) for f in params['board_conf_files']]
        ctx = self.create_ctx(
            uri,
            params['root'],
            confFiles,
            board_conf_files,
            params['env'],
            ctxId,
            build_context_name,
        )

        # This is the active build. Parse it right away:
        if ctxId == self.main_ctxId:
            self.refresh_ctx(ctx)
        return {'ctxId': ctxId}

    @handler('kconfig/getConfFileBuilds')
    def handle_get_conf_file_builds(self, params):
        uri = Uri.parse(params['uri'])
        result = []
        for ctxId in self.ctx:
            ctx = self.ctx[ctxId]
            for file in ctx.all_conf_files:
                if file.uri.path == uri.path:
                    result.append(
                        {
                            'ctxId': ctxId,
                            'app_dir': ctx.env.get('APPLICATION_SOURCE_DIR'),
                            'build_dir': ctx.uri.path,
                            'build_context_name': ctx.build_context_name,
                        }
                    )
                    break

        return result

    @handler('kconfig/getAllBuilds')
    def handle_get_all_conf_file_builds(self, params):

        result = []
        for ctxId in self.ctx:
            ctx = self.ctx[ctxId]
            result.append(
                {
                    'ctxId': ctxId,
                    'app_dir': ctx.env.get('APPLICATION_SOURCE_DIR'),
                    'build_dir': ctx.uri.path,
                    'build_context_name': ctx.build_context_name,
                }
            )

        return result

    @handler('kconfig/removeBuild')
    def handle_remove_build(self, params):
        ctxId = params['ctxId']

        if self.ctx.get(ctxId):
            if self.main_ctxId == ctxId:
                self.main_ctxId = None
                self.main_uri = None
                self.reset_ctx_diag(ctxId)

            del self.ctx[ctxId]
            print('Deleted build ' + ctxId)

    @handler('kconfig/setMainBuild')
    def handle_set_build(self, params):
        uri = Uri.parse(params['uri'])
        ctxId = params['ctxId']

        if self.main_ctxId == ctxId:
            return

        if self.main_ctxId is not None:
            self.reset_ctx_diag(self.main_ctxId)

        self.main_uri = uri
        self.main_ctxId = ctxId

        ctx = self.ctx.get(str(self.main_ctxId))
        if ctx:
            print(f'Main build: {ctxId}')
            print('\t' + "\n\t".join([str(f) for f in ctx.conf_files]))
            self.refresh_ctx(ctx)

    @handler('kconfig/clearMainBuild')
    def handle_clear_build(self, params):
        if self.main_ctxId is not None:
            self.reset_ctx_diag(self.main_ctxId)

        self.main_uri = None
        self.main_ctxId = None

        print(f'No main build')

    @handler('kconfig/getMainBuild')
    def handle_get_build(self, params):
        ctx = self.ctx.get(str(self.main_ctxId))
        build_context_name = None
        if ctx is not None:
            build_context_name = ctx.build_context_name

        if self.main_uri is None:
            return None
        return {
            'uri': str(self.main_uri.path),
            'ctxId': self.main_ctxId,
            'build_context_name': build_context_name,
        }

    def get_ctx(self, ctxId) -> Optional[KconfigContext]:
        """Get context from ID, or fall back to other contexts."""
        if ctxId:
            return self.ctx.get(ctxId)
        if self.main_ctxId:
            return self.ctx.get(str(self.main_ctxId))
        return None

    @handler('kconfig/search')
    def handle_search(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return []

        results = ctx.symbol_search(params['query'], only_visible=False)
        remaining_item_count = 0
        if 'limit' in params:
            limit = params['limit']
            remaining_item_count = max(0, len(results) - limit)
            results = results[:limit]

        return {"results": results, "remaining": remaining_item_count}

    @handler('kconfig/getItem')
    def handle_get_item(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if ctx:
            return ctx.menu_item(params['name'])

    @handler('textDocument/didChange')
    def handle_change(self, params):
        super().handle_change(params)
        if self.active_ctx:
            self.refresh_ctx(self.active_ctx)

    @handler('kconfig/getMenu')
    def handle_get_menu(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return

        if not ctx.valid:
            self.refresh_ctx(ctx)

        return ctx.get_menu(params.get('id'))

    @handler('kconfig/getBuild')
    def handle_get_active_build(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return

        return {
            'uri': ctx.uri,
            'conf': [f.uri for f in ctx.conf_files],
            'build_context_name': ctx.build_context_name,
            'app_dir': ctx.env.get('APPLICATION_SOURCE_DIR'),
            'board_conf_files': [f.uri for f in ctx.board_conf_files],
        }

    @handler('kconfig/refresh')
    def handle_refresh(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return False

        self.refresh_ctx(ctx)
        return True

    @handler('kconfig/getVal')
    def handle_getval(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return
        symbol_name: str = params['name']
        if symbol_name.startswith(ctx.prefix):
            symbol_name = symbol_name[len(ctx.prefix) :]
        val = ctx.get(symbol_name)
        if val:
            return val.str_value

    @handler('kconfig/setVal')
    def handle_setval(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return

        successful = ctx.set(params.get('name'), params.get('val'), params.get('id'))
        if successful:
            self.notify_changed_values(ctx)
        return successful

    @handler('kconfig/resetVal')
    def handle_reset_val(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return

        name = params.get("name")
        if name:
            successful = ctx.reset(name)
        if successful:
            self.notify_changed_values(ctx)
        return successful

    @handler('kconfig/getDiff')
    def handle_get_diff(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx or not ctx.valid:
            return []

        changes = ctx.get_changes()
        symbols = changes.added
        for deletion in changes.deleted:
            sym = ctx.symbol(deletion.name)
            if sym:
                symbols.append(sym)

        return [DiffMenuItem.from_sym(ctx, sym) for sym in symbols]

    @handler('kconfig/getEdits')
    def handle_get_edits(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return []

        uri = Uri.parse(params['uri'])
        file = ctx.conf_file(uri)
        if not file:
            return []

        return ctx.get_edits(file)

    @handler('kconfig/getImports')
    def handle_get_imports(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        path = params.get('path')
        if not ctx:
            return []
        if not ctx.valid:
            self.refresh_ctx(ctx)
        return ctx.get_imports(path)

    @handler('kconfig/getMinimalConfig')
    def get_minimal_config(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return

        board_entries = []
        for f in ctx.board_conf_files:
            for e in ConfFile.entries(self.documentStore.get(f.uri), ctx.prefix):
                board_entries.append(e.name)

        min_config = ctx.get_min_config()
        print(min_config)
        if min_config is not None:
            return '\n'.join(
                [
                    conf_string(sym, ctx.prefix)
                    for sym in min_config
                    if not sym.name in board_entries
                ]
            )

    @handler('kconfig/save')
    def handle_save(self, params):
        ctx = self.get_ctx(params.get('ctxId'))
        if not ctx:
            return

        return ctx.save()

    # @handler('kconfig/getEntry')
    # def handle_getentry(self, params):
    #     pass # TODO: Should get the "help" page for the entry

    @handler('textDocument/completion')
    def handle_completion(self, params):
        uri = Uri.parse(params['textDocument']['uri'])
        ctx = self.active_ctx
        if ctx is None:
            print('No context for {}'.format(uri.path))
            return

        if not ctx.valid:
            self.refresh_ctx(ctx)
            if not ctx.valid:
                return

        doc = self.documentStore.get(uri)
        if not doc:
            print('Unknown document')
            return

        language = _language(uri)
        if language not in ['conf', 'kconfig']:
            # Ignoring C files, as they should get completion results from other language servers.
            return

        pos = Position.create(params['position'])
        line = doc.line(pos.line)
        show_non_visible = False
        prefix = None
        word = None
        if line:
            prefix = line[: pos.character]
            # The entire line up to the cursor must be valid identifiers (alphanumeric and _)
            # in conf files to avoid providing completions in comments, strings or values:
            if language == 'conf' and not prefix.isidentifier():
                return

            # Get the last word at the cursor:
            if len(prefix) > 0 and prefix[-1].isidentifier():
                word = prefix.split().pop()

            if word:
                # Ensure word starts with 'CONFIG_'. By using commonprefix, we can also detect and correct
                # partial matches:
                common = os.path.commonprefix([word, ctx.prefix])
                if len(common) < len(ctx.prefix):
                    word = ctx.prefix + word[len(common) :]
                elif language == 'conf':
                    # Only show non-visible symbols in conf files:
                    show_non_visible = True

        if language == 'kconfig':
            # Kconfig files should only get completion suggestions if the current line can have symbol references
            if not prefix:
                return

            keywords = ['depends on ', 'default ', 'select ', 'imply ']

            # ignore indentation:
            prefix = prefix.lstrip()

            # "if" may appear anywhere, keywords should appear at the start of the line:
            if 'if' not in prefix.split() and not any(
                keyword for keyword in keywords if prefix.startswith(keyword)
            ):
                return

        def insert_text(sym: kconfig.Symbol):
            insert = Snippet(not_optional(ctx).prefix)
            insert.add_text(cast(str, sym.name))
            insert.add_text('=')
            if sym.type in [kconfig.BOOL, kconfig.TRISTATE]:
                choices = [kconfig.TRI_TO_STR[val] for val in list(sym.assignable)]
                choices.reverse()  # sym.assignable shows 'n' first, but user normally wants 'y'
                insert.add_choice(choices)
            elif sym.type == kconfig.STRING:
                insert.add_text('"')
                insert.add_tabstop()
                insert.add_text('"')
            elif sym.type == kconfig.HEX:
                insert.add_text('0x')
            else:
                pass  # freeform value

            return insert.text

        def completion_item(sym):
            item = {
                'label': not_optional(ctx).prefix + sym.name,
                'kind': CompletionItemKind.VARIABLE,
                'detail': kconfig.TYPE_TO_STR[sym.type],
                'documentation': next(
                    (n.help.replace('\n', ' ') for n in sym.nodes if n.help), ' '
                ),
            }

            # Only conf files should generate a snippet that inserts a value.
            # In all other file types, we're just looking to reference the value.
            if language == 'conf':
                item['insertText'] = insert_text(sym)
                item['insertTextFormat'] = InsertTextFormat.SNIPPET
            elif language == 'kconfig':
                # In Kconfig files, the CONFIG_ prefix shouldn't be included:
                item['label'] = sym.name

            return item

        # Only show visible symbols on completion without a prefix
        items = [
            completion_item(sym) for sym in ctx.symbols(word) if sym.visibility or show_non_visible
        ]

        print('Filter: "{}" Results: {}'.format(word, len(items)))
        # When performing a completion request without any prefix, we'll only show the visible symbols.
        # Since we want to start showing users non-visible symbols when they start typing, we need
        # to mark the non-prefixed completion list incomplete to make the client re-requests a new list
        return {'isIncomplete': not show_non_visible, 'items': items}

    @handler('textDocument/definition')
    def handle_definition(self, params):
        sym = self.get_sym(params)
        if sym:
            return loc(sym)

    @handler('textDocument/hover')
    def handle_hover(self, params):
        uri = Uri.parse(params['textDocument']['uri'])
        ctx = self.active_ctx
        if not ctx:
            print('No context for {}'.format(uri.path))
            return

        if not ctx.valid:
            self.refresh_ctx(ctx)

        sym = ctx.symbol_at(uri, Position.create(params['position']))
        if not sym:
            return

        contents = MarkupContent('')

        prompt = get_prompt(sym, True)
        if prompt:
            contents.add_text(prompt)

        contents.paragraph()
        contents.add_markdown('Type: `{}`'.format(kconfig.TYPE_TO_STR[sym.type]))
        if len(sym.str_value) > 0:
            contents.linebreak()
            contents.add_markdown('Value: `{}`'.format(sym.str_value))
        contents.paragraph()

        help = '\n\n'.join([n.help.replace('\n', ' ') for n in sym.nodes if n.help])
        if help:
            contents.add_text(help)

        if _language(uri) != 'conf' and len(ctx.conf_files) != 0:
            contents.paragraph()
            contents.add_markdown(
                '_Kconfig environment: [{}]({})_'.format(
                    ctx.build_context_name,
                    ctx.conf_files[0].uri,
                )
            )

        return {'contents': contents}

    @handler('textDocument/documentSymbol')
    def handle_doc_symbols(self, params):
        uri = Uri.parse(params['textDocument']['uri'])
        ctx = self.active_ctx
        if ctx is None:
            return

        if not ctx.valid:
            self.refresh_ctx(ctx)

        file = ctx.conf_file(uri)
        if not file:
            return

        def doc_sym(ctx: KconfigContext, e: ConfEntry):
            sym = ctx.get(e.name)
            if sym:
                prompt = get_prompt(sym, True)
            else:
                prompt = None
            return DocumentSymbol(ctx.prefix + e.name, SymbolKind.PROPERTY, e.full_range, prompt)

        return [
            doc_sym(ctx, e) for e in ConfFile.entries(self.documentStore.get(file.uri), ctx.prefix)
        ]

    @handler('workspace/symbol')
    def handle_workspace_symbols(self, params):
        query = params['query']
        ctx = self.active_ctx
        if not ctx:
            return
        if not ctx.valid:
            self.refresh_ctx(ctx)

        def sym_info(sym: kconfig.Symbol):
            return SymbolInformation(
                not_optional(ctx).prefix + cast(str, sym.name),
                SymbolKind.PROPERTY,
                loc(sym)[0],
                get_prompt(sym, True),
            )

        return [sym_info(s) for s in ctx.symbols(query) if len(s.nodes)]

    @handler('textDocument/codeAction')
    def handle_code_action(self, params):
        uri = Uri.parse(params['textDocument']['uri'])
        ctx = self.active_ctx
        if not ctx:
            self.notify_status(ctx)
            print('No context for {}'.format(uri.path))
            return

        if not ctx.valid:
            self.refresh_ctx(ctx)

        range = Range.create(params['range']) if 'range' in params else None

        if _language(uri) == 'c':
            return ctx.get_setval_actions(Location(uri, range))

        conf = ctx.conf_file(uri)
        if not conf:
            print('No conf file for {}'.format(uri.path))
            return

        actions = []
        for diag in conf.diags:
            if range is not None and range.overlaps(diag.range):
                actions.extend(diag.actions)

        return actions

    def on_file_change(self, uri: Uri, kind: FileChangeKind):
        if uri.basename.startswith('Kconfig'):
            for ctx in self.ctx.values():
                if ctx.in_kconfig_tree(uri):
                    ctx.invalidate()
                    print(f'Invalidated {ctx} because of change in {uri}')
        elif uri.basename == 'edt.pickle':
            # When the DTS context for this context changes, it should be invalidated:
            changedCtx = self.ctx.get(str(Uri.file(uri.path.replace('/zephyr/edt.pickle', ''))))
            if changedCtx:
                changedCtx.invalidate()
                print(f'Invalidated {changedCtx} due to dts changes.')
        elif uri.basename == 'kconfigfunctions.py':
            for ctx in self.ctx.values():
                ctx.invalidate()
                print(f'Invalidated {ctx} because of change in {uri}')

    @handler('textDocument/didSave')
    def handle_did_save(self, params):
        uri = Uri.parse(params['textDocument']['uri'])
        if uri.basename.startswith('Kconfig'):
            for ctx in self.ctx.values():
                if ctx.in_kconfig_tree(uri):
                    ctx.invalidate()
                    print(f'Invalidated {ctx} because of change in {uri}')


def wait_for_debugger():
    try:
        import debugpy  # type: ignore

        debugpy.connect(5678)  # Do not wait for client to attach
    except ImportError:
        print('debugpy is missing, debugging disabled')
        print(f'Python version: {sys.version} ({sys.executable})')
    except ConnectionRefusedError:
        print('No debugger attached')


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode.',
    )
    parser.add_argument(
        '--log',
        action='store_true',
        help='Enable logging. Will write debug logs to an lsp.log file in the current working directory.',
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    srv = KconfigServer()
    sys.stdout = srv.log
    sys.stderr = srv.err

    print("Server starting")

    if args.debug:
        wait_for_debugger()

    if args.log:
        srv.logging = True

    srv.loop()
