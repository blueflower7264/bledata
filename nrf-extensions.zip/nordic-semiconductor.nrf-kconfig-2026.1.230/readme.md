# nRF Kconfig

Nordic Semiconductor’s nRF Kconfig is part of the [nRF Connect Extension Pack](https://marketplace.visualstudio.com/items?itemName=nordic-semiconductor.nrf-connect-extension-pack), featuring a more intuitive GUI for the [Kconfig](https://www.kernel.org/doc/html/latest/kbuild/kconfig-language.html) structure and support for the Kconfig language in VS Code.
This allows you to easily search through and control the Kconfig options in your projects.

## Features

nRF Kconfig features a **nRF Kconfig GUI** that displays your project's Kconfig options from the build configuration's `.config` file in a neat, treeview menu. From the **nRF Kconfig GUI**, you can enable or disable nodes and navigate through your search history made within the GUI.

![nRF Kconfig GUI](https://docs-be.nordicsemi.com/bundle/nrf-connect-vscode/page/screenshots/gif/kconfig_changes.gif "nRF Kconfig GUI")

The extension also offers a variety of improvements for the Kconfig language, configuration files, and C files such as:

- Syntax highlighting and autocompletion
- Linting, including type checking for configuration values, dependency checking, and more
- Customization of Kconfig options
- [Breadcrumbs](https://code.visualstudio.com/docs/editor/editingevolved#_breadcrumbs) navigation
- [Code Actions](https://code.visualstudio.com/docs/editor/editingevolved#_code-action), such as add missing dependencies and remove redundant entries

For detailed information about the extension, see the [Kconfig UI](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_kconfig.html) documentation site.

## Feedback

Let us know what you think using the [**Give Feedback**](https://docs.nordicsemi.com/bundle/nrf-connect-vscode/page/reference/ui_sidebar_welcome.html#toolbar-actions) form within the extension, or ask questions in the [Nordic DevZone](https://devzone.nordicsemi.com/).