# BLE Cellular Hub v0.1

This is a clean hub project for the nRF52840 DK.

The goal is to coordinate local smart-room devices over BLE, expose a local Web
Bluetooth controller, and leave a clean path for a future NB-IoT/cellular uplink.

## v0.1 Scope

- BLE peripheral service for the web controller.
- Manual QR/custom-code onboarding path.
- BLE scanner that tries to match onboarded devices by BLE address or name.
- Nearby BLE discovery list that the web controller can request.
- Device registry with Zephyr settings/NVS persistence.
- SwitchBot Curtain 3 GATT control path.
- Xiaomi temperature/humidity advertisement parser.
- Mijia-compatible button advertisement event path.
- Zengge/Telink RGBW bulb GATT discovery path.
- IR appliance and mesh relay extension points.

## Build

From the workspace root:

```powershell
west build -b nrf52840dk/nrf52840 -d ble_cellular_hub_v0.1/build ble_cellular_hub_v0.1
```

## Flash

```powershell
west flash -d ble_cellular_hub_v0.1/build
```

## Web Controller

Open `web_controller/index.html` through the included PowerShell server:

```powershell
cd ble_cellular_hub_v0.1\web_controller
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```

Then open:

```text
http://localhost:8000
```

Use Chrome or Edge because Web Bluetooth is required.

## Target Devices

This copied project is centered on four devices:

- SwitchBot Curtain 3
- Mijia-compatible Bluetooth button
- Zengge RGBW bulb using Telink mesh-over-GATT
- Xiaomi temperature/humidity sensor 3 mini

See `FOUR_DEVICE_INTEGRATION.md` for the exact integration plan and current
driver status.

The app-facing BLE contract is documented in `APP_PROTOCOL_CONTRACT.md`. Share
that file with the app team and treat it as the v0.1 source of truth.

## Custom QR Payload

For now the web controller accepts readable JSON. Example:

```json
{
  "v": 1,
  "kind": "hub_device",
  "type": "curtain",
  "driver": "switchbot_curtain_3",
  "id": "bedroom_curtain",
  "name": "Bedroom Curtain",
  "ble": {
    "addr": "AA:BB:CC:DD:EE:FF",
    "name": "WoCurtain"
  }
}
```

The browser parses this JSON and sends a compact binary command to the hub. The
firmware does not parse JSON.

## First Device Targets

The first practical targets are:

- **Temp/humidity:** Xiaomi `LYWSD03MMC` style monitor.
- **Curtain:** SwitchBot Curtain 3.
- **Bulb:** Yeelight/Mijia BLE bulb family as the first China-friendly target.

The exact vendor command details still need to be confirmed with real hardware.
For now, v0.2 helps us see nearby BLE devices and match them against custom QR
labels.

## SwitchBot Curtain 3 Test

The hub can now route the web `Test` button to the first onboarded
`switchbot_curtain_3` device.

Flow:

1. Flash `build_v03`.
2. Open the web controller.
3. Connect to `BleCellHub`.
4. Click `Scan`, then `Nearby`.
5. Copy the Curtain 3 address into the Curtain sample payload.
6. Click `Add`.
7. Click `Test`.

The test path:

```text
connect by BLE address
discover SwitchBot service/characteristics
subscribe to notifications
send position 50 command
```

Expected status messages include:

```text
CURTAIN_CONNECTING
CURTAIN_CONNECTED
CURTAIN_SERVICE_FOUND
CURTAIN_READY
CURTAIN_POSITION_SENT value=50
```

## v0.3 Room Hub Features

This build adds the first larger hub behaviors:

- Onboarded devices are saved with Zephyr settings/NVS and loaded at boot.
- Xiaomi `LYWSD03MMC`/ATC-style BLE temperature and humidity advertisements are
  parsed when visible.
- The device registry stores latest temperature, humidity, battery, RSSI, and
  last-seen time.
- Web buttons can trigger Sleep, Wake, All Off, and a short demo schedule.
- Sleep/Wake scenes call the Curtain 3 driver when a `switchbot_curtain_3`
  curtain is onboarded.
- Bulb and IR scene hooks exist, but their real vendor command bytes still need
  hardware-specific driver work.
