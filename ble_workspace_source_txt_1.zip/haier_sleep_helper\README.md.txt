# Haier Sleep Helper

Small Zephyr/NCS app for the nRF52840 DK.

The app sends Haier AC160 IR commands through a PWM-driven IR LED. It runs a
simple overnight schedule intended to improve sleep comfort and reduce
overcooling.

## Controls

```text
Button 1: start/stop sleep helper
Button 2: resend current schedule step
Button 3: lower current temperature by 1 C and send
Button 4: raise current temperature by 1 C and send
```

Stopping the helper only stops automation. It does not send an AC-off command.

## LED Feedback

```text
LED1 off: helper inactive
LED1 on: helper active
LED2 blink: transmitting IR
LED3/LED4: current step indicator, shown as two binary bits
```

Step indicator examples:

```text
Step 1: LED3 on,  LED4 off
Step 2: LED3 off, LED4 on
Step 3: LED3 on,  LED4 on
Step 4: LED3 off, LED4 off
```

For steps beyond four, the two-bit indicator wraps. The serial log prints the
exact step number.

## Schedule

The default real schedule is:

```text
T+0h: AC on, cool, 24 C, fan auto
T+1h: AC on, cool, 25 C, fan auto
T+2h: AC on, cool, 26 C, fan auto
T+4h: AC off
T+6h: AC on, cool, 26 C, fan auto
T+7h: AC on, cool, 25 C, fan auto
```

Edit `sleep_schedule[]` in `src/main.c` to change the schedule. Manual
temperature changes only affect the current running step. The next scheduled
step applies its configured temperature from the table.

## Demo Mode

Demo mode is enabled by default:

```c
#define DEMO_MODE 1
#define DEMO_STEP_SECONDS 10
```

With demo mode enabled, the same schedule advances every 10 seconds instead of
waiting for real overnight timing. After testing, change `DEMO_MODE` to `0`.

## Wiring

Default PWM output is **Arduino D7**, which maps to `P1.08` on the nRF52840 DK.
This matches the earlier Keil/Arduino-style IR wiring.

The app overlay disables SPI1 because the DK also maps SPI1 MISO to `P1.08`.
For actual AC range, drive the IR LED through a transistor or MOSFET:

```text
Arduino D7 / P1.08 -> base/gate resistor -> transistor/MOSFET input
IR LED + resistor -> transistor/MOSFET -> GND
```

Do not drive a high-current IR LED directly from the DK GPIO.

## Build

```powershell
west build -b nrf52840dk/nrf52840 . -p always
```

## Flash

```powershell
west flash
```

## Protocol Note

This uses Haier AC160 as the first protocol to try for `KFR-26GW/AOMCC83`.
If the AC does not respond, capture the original remote with a 38 kHz IR
receiver and compare the raw packet.
