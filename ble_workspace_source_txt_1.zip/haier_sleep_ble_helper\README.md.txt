# Haier Sleep BLE Helper

This project is a Bluetooth-controlled version of `haier_sleep_helper`.
The original IR-only project is left untouched.

The nRF52840 DK still sends Haier AC160 IR commands through an IR LED on
Arduino D7 / `P1.08`. It also advertises as a BLE peripheral named
`HaierSleep`.

## Hardware

- Board: nRF52840 DK
- IR signal pin: Arduino D7 / `P1.08`
- GND: DK GND
- Use a transistor driver for the IR LED if you need useful range.

The overlay disables `spi1` because the DK also maps SPI1 MISO to `P1.08`.
That frees Arduino D7 for PWM-based IR output.

## Buttons and LEDs

- Button 1: start/stop the helper
- Button 2: resend the current AC state
- Button 3: lower current temperature by 1 C
- Button 4: raise current temperature by 1 C
- LED 1: helper active
- LED 2: IR transmit blink
- LED 3/4: current schedule step indicator

## BLE Interface

Device name:

```text
HaierSleep
```

Service UUID:

```text
7a7e0000-82c7-4c91-a287-2b73c635a901
```

Control characteristic, write 1 byte:

```text
7a7e0001-82c7-4c91-a287-2b73c635a901

0x01 start
0x02 stop
0x03 resend current state
0x04 temp down
0x05 temp up
0x06 toggle start/stop
```

Config characteristic, read/write 5 bytes:

```text
7a7e0002-82c7-4c91-a287-2b73c635a901

byte 0: start temp C
byte 1: deep sleep temp C
byte 2: wake temp C
byte 3: turn AC off during deep sleep, 0 or 1
byte 4: demo mode, 0 or 1
```

Status characteristic, read/notify 8 bytes:

```text
7a7e0003-82c7-4c91-a287-2b73c635a901

byte 0: helper active, 0 or 1
byte 1: current step, 1-based
byte 2: total steps
byte 3: AC power state, 0 or 1
byte 4: current temp C
byte 5: IR sending, 0 or 1
byte 6: demo mode, 0 or 1
byte 7: turn off at deep sleep, 0 or 1
```

## Build and Flash

```powershell
west build -b nrf52840dk/nrf52840 -d haier_sleep_ble_helper/build haier_sleep_ble_helper
west flash -d haier_sleep_ble_helper/build
```

## Web Control

Use the `web_controller` page inside this project. Serve it from `localhost`,
then open it in Chrome or Edge.

No Python or Node install is required. Use the bundled PowerShell server:

```powershell
cd haier_sleep_ble_helper\web_controller
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```

Then open:

```text
http://localhost:8000
```
