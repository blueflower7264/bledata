# SwitchBot Curtain Probe

This project is the direct-Bluetooth investigation step for controlling a
SwitchBot Curtain 3 from the nRF52840 DK.

It scans first. When it sees a likely Curtain/SwitchBot device name, it stops
scanning, connects, and discovers GATT services and characteristics.

It does not pair. It can send reference commands manually after discovery.
It also subscribes to the SwitchBot notify characteristic and prints response
bytes from the device.

The command draft follows PySwitchbot's Curtain 3 command shape:

- service UUID: `cba20d00-224d-11e6-9fb8-0002a5d5c51b`
- write UUID: `cba20002-224d-11e6-9fb8-0002a5d5c51b`
- notify UUID: `cba20003-224d-11e6-9fb8-0002a5d5c51b`

Manual button commands:

- Button 1: stop
- Button 2: open
- Button 3: close
- Button 4: set position 50 percent

## Target Address Mode

By default, the probe connects by name. It looks for names like `WoCurtain`,
`Curtain`, or `SwitchBot`.

After you have the real Curtain 3 and see its address in the serial log, you
can make the probe connect only to that device. Edit this line in `src/main.c`:

```c
#define TARGET_ADDR ""
```

For example:

```c
#define TARGET_ADDR "AA:BB:CC:DD:EE:FF"
```

When `TARGET_ADDR` is not empty, name matching is ignored.

## What To Watch

Open the DK serial log at `115200` baud. The probe prints nearby BLE devices:

```text
[BLE] xx:xx:xx:xx:xx:xx (...) rssi=-55 type=connectable name="WoCurtain3"
  manufacturer: len=...
  service data 16: len=...
```

For the next step, save the lines that look like the Curtain 3. Useful values:

- address
- name
- RSSI
- manufacturer data
- service data
- service UUID data
- GATT service UUIDs
- GATT characteristic UUIDs and properties
- whether the log says `SwitchBot write characteristic found`
- whether the log says `SwitchBot notifications subscribed`
- any `SwitchBot notify:` response bytes after pressing a button
- whether the button write is accepted or returns an error

## Build and Flash

```powershell
west build -b nrf52840dk/nrf52840 -d switchbot_curtain_probe/build_ready switchbot_curtain_probe
west flash -d switchbot_curtain_probe/build_ready
```

If `west` is not available in the terminal, use the nRF Connect VS Code
extension to build and flash.

## Serial Log

Use the nRF Connect VS Code serial terminal, nRF Connect for Desktop Serial
Terminal, PuTTY, or Tera Term.

Settings:

```text
Baud: 115200
Data bits: 8
Parity: none
Stop bits: 1
Flow control: none
```
