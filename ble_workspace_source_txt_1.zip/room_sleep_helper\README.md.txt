# Room Sleep Helper

This is the advanced sleep-helper project. It combines:

- Haier AC control through an IR LED on Arduino D7 / `P1.08`
- Browser control over BLE using the bundled `web_controller`
- Reference SwitchBot Curtain 3 control over direct BLE

The original `haier_sleep_ble_helper` project remains the stable AC-only
version.

## Current Status

The Haier AC path is copied from the working BLE sleep helper.

The SwitchBot Curtain path is reference-based and not hardware-validated yet.
It uses the same UUIDs and command shape as PySwitchbot:

- service UUID: `cba20d00-224d-11e6-9fb8-0002a5d5c51b`
- write UUID: `cba20002-224d-11e6-9fb8-0002a5d5c51b`
- notify UUID: `cba20003-224d-11e6-9fb8-0002a5d5c51b`

## Sleep Schedule

In demo mode, each step runs every 10 seconds.

```text
Step 1: close curtain, AC cool start temp
Step 2: AC moves toward deep sleep temp
Step 3: AC deep sleep temp
Step 4: AC off if enabled
Step 5: curtain 20%, AC wake temp
Step 6: curtain 80%, AC wake temp
```

Curtain position follows SwitchBot convention:

```text
0   open
100 closed
```

## SwitchBot Target Address

By default, the firmware scans for names like `WoCurtain`, `Curtain`, or
`SwitchBot`.

After you test with the real Curtain 3, edit this in
`src/switchbot_curtain.h`:

```c
#define SWITCHBOT_CURTAIN_TARGET_ADDR ""
```

Example:

```c
#define SWITCHBOT_CURTAIN_TARGET_ADDR "AA:BB:CC:DD:EE:FF"
```

## Build and Flash

```powershell
west build -b nrf52840dk/nrf52840 -d room_sleep_helper/build room_sleep_helper
west flash -d room_sleep_helper/build
```

## Web Controller

No Python or Node install is required. Use the bundled PowerShell server:

```powershell
cd room_sleep_helper\web_controller
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```

Open Chrome or Edge:

```text
http://localhost:8000
```
