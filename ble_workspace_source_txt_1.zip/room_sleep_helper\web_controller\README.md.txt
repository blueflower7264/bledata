# Room Sleep Web Controller

This page controls the `room_sleep_helper` firmware over Web Bluetooth.

Run from this folder with the bundled PowerShell server:

```powershell
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```

Open in Chrome or Edge:

```text
http://localhost:8000
```

The current UI controls the AC sleep parameters. Curtain actions are tied to
the firmware schedule for now.
