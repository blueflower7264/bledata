# Web Sleep Controller

This is a small Web Bluetooth controller for the `haier_sleep_ble_helper`
firmware.

## Run

Web Bluetooth needs a secure context. `localhost` is allowed, so serve this
folder locally with the bundled PowerShell server:

```powershell
cd haier_sleep_ble_helper\web_controller
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```

Open this in Chrome or Edge:

```text
http://localhost:8000
```

Click `Connect`, choose `HaierSleep`, then edit the sleep parameters or send
commands.

## Requirements

- Chrome or Edge
- PC Bluetooth enabled
- nRF52840 DK flashed with `haier_sleep_ble_helper`
